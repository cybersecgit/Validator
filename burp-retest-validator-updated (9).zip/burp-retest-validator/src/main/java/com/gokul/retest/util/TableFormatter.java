package com.gokul.retest.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Greedy word-wrap helper shared by the results table's row-height
 * calculation and the screenshot banner's sizing — both need to know how
 * many lines a given piece of text will wrap into at a given character
 * width, without relying on Swing's own (harder-to-predict-ahead-of-time)
 * text layout.
 */
public final class TableFormatter {

    private TableFormatter() { }

    /**
     * Greedy word-wrap to a fixed column width. Splits any single token
     * longer than the column (e.g. a long URL with no spaces) so it never
     * exceeds the given width.
     */
    public static List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            lines.add("");
            return lines;
        }
        for (String paragraph : text.split("\n", -1)) {
            StringBuilder current = new StringBuilder();
            for (String word : paragraph.split(" ")) {
                while (word.length() > width) {
                    if (current.length() > 0) {
                        lines.add(current.toString());
                        current.setLength(0);
                    }
                    lines.add(word.substring(0, width));
                    word = word.substring(width);
                }
                if (current.length() == 0) {
                    current.append(word);
                } else if (current.length() + 1 + word.length() <= width) {
                    current.append(' ').append(word);
                } else {
                    lines.add(current.toString());
                    current.setLength(0);
                    current.append(word);
                }
            }
            lines.add(current.toString());
        }
        return lines;
    }
}
