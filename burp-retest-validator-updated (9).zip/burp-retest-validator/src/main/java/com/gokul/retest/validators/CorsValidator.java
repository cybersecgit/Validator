package com.gokul.retest.validators;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.CookieUtils;
import com.gokul.retest.util.HeaderUtils;

import java.util.List;
import java.util.Optional;

/**
 * Single CORS validator replacing the old "CORS Misconfiguration" +
 * "Send probe Origin header" checkbox pair. It always sends an
 * arbitrary-origin probe (so it's testing origin *reflection*, not just
 * re-reading whatever Origin the original request happened to carry),
 * and separately probes with a literal "null" Origin to cover the
 * null-origin bypass pattern. It then classifies the result against
 * the same matrix testers use manually:
 *
 *   a. ACAO reflects request Origin + ACAC:true + cookie auth           -> FAIL (unfixed)
 *   b. ACAO reflects request Origin + ACAC:true + no cookie auth        -> PASS (fixed)
 *   c. ACAO reflects request Origin + ACAC:true + ACA-Headers:Authorization -> FAIL (unfixed)
 *   d. ACAO: null + ACAC:true + cookie auth + no X-Frame-Options        -> FAIL (unfixed)
 *   e. ACAO: *                                                          -> PASS (fixed)
 *   f. ACAO present but doesn't reflect the probe Origin (a fixed/
 *      allowlisted value instead)                                      -> PASS (fixed)
 *
 * Needs its own outbound HTTP calls (the arbitrary-origin probe and the
 * null-origin probe), so it takes a MontoyaApi reference at
 * construction time rather than relying solely on validate(request,response).
 * validate(request,response) is kept as a best-effort fallback for
 * direct/programmatic use (e.g. unit tests) — it evaluates only
 * scenarios a/b/c/e off of whatever request/response it's given, since
 * it has no way to send the extra null-Origin probe itself.
 */
public class CorsValidator implements Validator {

    private final MontoyaApi api;

    public CorsValidator(MontoyaApi api) {
        this.api = api;
    }

    @Override
    public String name() { return "CORS Misconfiguration"; }

    @Override
    public String category() { return "Security Misconfiguration — CORS"; }

    /**
     * Primary entry point used by the UI runner. Sends its own probes
     * (arbitrary-Origin reflection check + null-Origin check) rather than
     * relying on whatever the caller already replayed.
     */
    public ValidationResult validateWithProbes(HttpRequest baseRequest) {
        String probeOrigin = pickProbeOrigin(baseRequest);
        HttpRequest probeRequest = withOriginHeader(baseRequest, probeOrigin);

        HttpResponse probeResponse;
        try {
            probeResponse = api.http().sendRequest(probeRequest).response();
        } catch (Exception ex) {
            return ValidationResult.inconclusive("CORS arbitrary-Origin probe request failed: " + ex.getMessage());
        }
        if (probeResponse == null) {
            return ValidationResult.inconclusive("No response received for CORS arbitrary-Origin probe.");
        }

        // Attach the actual probe request/response as this result's evidence
        // pair so the saved screenshot shows the arbitrary Origin that was
        // sent (and the headers the server sent back for it), rather than
        // falling back to the generic baseline replay.
        ValidationResult primary = classify(probeRequest, probeResponse, probeOrigin)
                .withEvidence(probeRequest, probeResponse);

        // Secondary probe: literal "null" Origin, for scenario (d). Best
        // effort — if it fails, we still return the primary classification.
        HttpRequest nullRequest = withOriginHeader(baseRequest, "null");
        HttpResponse nullResponse = null;
        try {
            nullResponse = api.http().sendRequest(nullRequest).response();
        } catch (Exception ignored) {
            // Non-fatal — null-origin probe is a supplementary check.
        }

        if (nullResponse != null) {
            Optional<ValidationResult> nullOriginFinding = checkNullOriginScenario(baseRequest, nullResponse);
            if (nullOriginFinding.isPresent()) {
                // A confirmed null-origin bypass is a FAIL regardless of what
                // the primary arbitrary-origin probe found. Evidence pair is
                // the null-Origin probe that triggered it.
                return nullOriginFinding.get().withEvidence(nullRequest, nullResponse);
            }
        }

        return primary;
    }

    /**
     * Fallback for direct/programmatic use without a live MontoyaApi probe
     * cycle (e.g. tests, or if this validator is invoked generically like
     * any other Validator). Classifies scenarios a/b/c/e from whatever
     * request/response pair it's handed; cannot check scenario (d) since
     * that needs its own separate null-Origin request.
     */
    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        String requestOrigin = request.headerValue("Origin");
        return classify(request, response, requestOrigin);
    }

    private String pickProbeOrigin(HttpRequest baseRequest) {
        return "https://retest-probe.example";
    }

    /**
     * Sets the Origin header to the given value, adding it if the baseline
     * request doesn't already carry one (a plain browser navigation
     * request usually won't). withUpdatedHeader() on some Montoya
     * versions is update-only and is a no-op when the header is absent,
     * which would silently send the probe with no Origin header at all —
     * so presence is checked explicitly here rather than assumed.
     */
    private HttpRequest withOriginHeader(HttpRequest request, String originValue) {
        return request.headerValue("Origin") != null
                ? request.withUpdatedHeader("Origin", originValue)
                : request.withAddedHeader("Origin", originValue);
    }

    private ValidationResult classify(HttpRequest request, HttpResponse response, String requestOrigin) {
        List<HttpHeader> headers = response.headers();

        Optional<List<String>> acaoDup = HeaderUtils.duplicateWithDifferentValues(headers, "Access-Control-Allow-Origin");
        if (acaoDup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate Access-Control-Allow-Origin headers with different values: " + String.join("\n", acaoDup.get()),
                    acaoDup.get().toArray(new String[0]));
        }
        Optional<List<String>> acacDup = HeaderUtils.duplicateWithDifferentValues(headers, "Access-Control-Allow-Credentials");
        if (acacDup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate Access-Control-Allow-Credentials headers with different values: " + String.join("\n", acacDup.get()),
                    acacDup.get().toArray(new String[0]));
        }
        Optional<List<String>> acahDup = HeaderUtils.duplicateWithDifferentValues(headers, "Access-Control-Allow-Headers");
        if (acahDup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate Access-Control-Allow-Headers headers with different values: " + String.join("\n", acahDup.get()),
                    acahDup.get().toArray(new String[0]));
        }

        Optional<HttpHeader> acao = HeaderUtils.findFirst(headers, "Access-Control-Allow-Origin");
        Optional<HttpHeader> acac = HeaderUtils.findFirst(headers, "Access-Control-Allow-Credentials");
        Optional<HttpHeader> acah = HeaderUtils.findFirst(headers, "Access-Control-Allow-Headers");

        if (acao.isEmpty()) {
            String acacLineIfAny = acac.map(HeaderUtils::line).orElse(null);
            return ValidationResult.pass(
                    "No Access-Control-Allow-Origin header returned for Origin: " + requestOrigin + ".",
                    acacLineIfAny);
        }

        String acaoLine = HeaderUtils.line(acao.get());
        String acacLine = acac.map(HeaderUtils::line).orElse(null);
        String acahLine = acah.map(HeaderUtils::line).orElse(null);
        String acaoVal = acao.get().value().trim();
        boolean credsAllowed = acac.isPresent() && acac.get().value().trim().equalsIgnoreCase("true");
        boolean cookieAuth = CookieUtils.requestUsesCookieAuth(request.headerValue("Cookie"));
        boolean acahHasAuthorization = acah.isPresent() && acah.get().value().toLowerCase().contains("authorization");

        // Scenario (e): wildcard ACAO — considered fixed, unless paired with
        // Allow-Credentials:true, which is invalid per the fetch spec but
        // worth flagging so the retest doesn't silently miss it.
        if (acaoVal.equals("*") && credsAllowed) {
            return ValidationResult.fail(
                    "ACAO: * combined with Access-Control-Allow-Credentials: true — invalid per spec "
                            + "(most browsers will reject this combination), but flagging for manual confirmation.",
                    acaoLine, acacLine);
        }
        if (acaoVal.equals("*")) {
            return ValidationResult.pass("ACAO: * with no Allow-Credentials — fixed (scenario e).", acaoLine, acacLine);
        }

        boolean reflectsOrigin = requestOrigin != null && acaoVal.equalsIgnoreCase(requestOrigin);

        if (!reflectsOrigin) {
            // The server did NOT echo our arbitrary probe Origin back —
            // that's the actual fix for the vulnerability class this probe
            // tests for (blind origin reflection). Whatever it returned
            // instead is presumably a fixed/allowlisted value, which is the
            // secure pattern, so this is a PASS rather than something to
            // review — previously this branch treated "didn't reflect" as
            // inconclusive, which had it flagging the *absence* of the bug
            // as something suspicious instead of confirming the fix.
            return ValidationResult.pass(
                    "Server did not reflect the arbitrary test Origin (" + requestOrigin + "); it returned "
                            + acaoVal + " instead — fixed (the endpoint isn't blindly echoing the Origin header). "
                            + "Worth a quick sanity check that " + acaoVal + " is a value you actually expect "
                            + "(the real origin or an approved partner), not something unexpected.",
                    acaoLine, acacLine);
        }

        // Scenario (a)/(c): reflected origin + credentials allowed, and either
        // cookie auth is in play, or Authorization is explicitly whitelisted
        // for cross-origin requests.
        if (credsAllowed && cookieAuth) {
            return ValidationResult.fail(
                    "Server reflects arbitrary Origin (" + requestOrigin + ") with Access-Control-Allow-Credentials: true, "
                            + "and the request carries a session cookie — cross-origin requests would run with the victim's "
                            + "cookies (scenario a).",
                    acaoLine, acacLine);
        }
        if (credsAllowed && acahHasAuthorization) {
            return ValidationResult.fail(
                    "Server reflects arbitrary Origin (" + requestOrigin + ") with Access-Control-Allow-Credentials: true, "
                            + "and Access-Control-Allow-Headers whitelists Authorization — a cross-origin script could attach "
                            + "a bearer token and have the request succeed (scenario c).",
                    acaoLine, acacLine, acahLine);
        }
        if (credsAllowed) {
            // Scenario (b): reflected + credentials allowed, but no cookie
            // auth and no Authorization whitelisting observed on this request.
            return ValidationResult.pass(
                    "Origin reflected with Allow-Credentials: true, but this request shows no cookie-based auth and "
                            + "Access-Control-Allow-Headers does not whitelist Authorization — fixed (scenario b). "
                            + "Note: only covers what this request's auth mechanism showed; if a different auth path uses "
                            + "cookies, retest that path separately.",
                    acaoLine, acacLine);
        }

        return ValidationResult.inconclusive(
                "Origin reflected without Allow-Credentials — lower risk for cookie-based attacks, but confirm the "
                        + "response doesn't expose sensitive data an anonymous cross-origin caller shouldn't see.",
                acaoLine, acacLine);
    }

    /** Scenario (d): null-Origin + Allow-Credentials:true + cookie auth + no X-Frame-Options. */
    private Optional<ValidationResult> checkNullOriginScenario(HttpRequest baseRequest, HttpResponse nullResponse) {
        List<HttpHeader> headers = nullResponse.headers();
        Optional<HttpHeader> acao = HeaderUtils.findFirst(headers, "Access-Control-Allow-Origin");
        Optional<HttpHeader> acac = HeaderUtils.findFirst(headers, "Access-Control-Allow-Credentials");
        Optional<HttpHeader> xfo = HeaderUtils.findFirst(headers, "X-Frame-Options");

        boolean acaoNull = acao.isPresent() && acao.get().value().trim().equalsIgnoreCase("null");
        boolean credsAllowed = acac.isPresent() && acac.get().value().trim().equalsIgnoreCase("true");
        boolean cookieAuth = CookieUtils.requestUsesCookieAuth(baseRequest.headerValue("Cookie"));
        boolean noXfo = xfo.isEmpty();

        if (acaoNull && credsAllowed && cookieAuth && noXfo) {
            String acaoLine = HeaderUtils.line(acao.get());
            String acacLine = HeaderUtils.line(acac.get());
            return Optional.of(ValidationResult.fail(
                    "Origin: null probe reflected as ACAO: null with Allow-Credentials: true, request uses cookie "
                            + "auth, and no X-Frame-Options is set — exploitable via a sandboxed iframe that gets a "
                            + "null Origin (scenario d).",
                    acaoLine, acacLine));
        }
        return Optional.empty();
    }
}
