package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.HeaderUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * CSP misconfiguration check.
 *
 * IMPORTANT — this is a local, offline heuristic, not a substitute for
 * https://csp-evaluator.withgoogle.com/. It re-implements the *shape* of
 * that tool's most common high-severity findings (unsafe-inline,
 * unsafe-eval, wildcard/overly broad script sources, missing object-src,
 * missing base-uri) so the extension can give a quick PASS/FAIL without
 * sending your target's CSP value to an external site. It does not cover
 * every check csp-evaluator does (e.g. it doesn't maintain a live list of
 * known JSONP-bypass CDN paths). Treat a PASS here as "no obvious
 * high-severity issue found by this heuristic" and still spot-check
 * meaningful policies against csp-evaluator manually, exactly as before.
 */
public class CspValidator implements Validator {

    @Override
    public String name() { return "CSP Misconfiguration"; }

    @Override
    public String category() { return "Security Misconfiguration — CSP"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        List<HttpHeader> headers = response.headers();

        Optional<List<String>> dup = HeaderUtils.duplicateWithDifferentValues(headers, "Content-Security-Policy");
        if (dup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate Content-Security-Policy headers with different values — browsers intersect multiple "
                            + "CSP headers, so verify the *effective* policy manually:\n" + String.join("\n", dup.get()),
                    dup.get().toArray(new String[0]));
        }

        Optional<HttpHeader> csp = HeaderUtils.findFirst(headers, "Content-Security-Policy");
        if (csp.isEmpty()) {
            return ValidationResult.fail("No Content-Security-Policy header present.");
        }

        String headerLine = HeaderUtils.line(csp.get());
        Map<String, String> directives = parseDirectives(csp.get().value());
        List<String> highSeverity = new ArrayList<>();

        String scriptSrc = directives.getOrDefault("script-src", directives.get("default-src"));
        if (scriptSrc == null) {
            highSeverity.add("No script-src or default-src directive — script sources are entirely unrestricted.");
        } else {
            String lower = scriptSrc.toLowerCase(Locale.ROOT);
            if (lower.contains("'unsafe-inline'")) {
                highSeverity.add("script-src/default-src allows 'unsafe-inline' — inline <script> and event handlers "
                        + "are not blocked, defeating most of CSP's XSS mitigation.");
            }
            if (lower.contains("'unsafe-eval'")) {
                highSeverity.add("script-src/default-src allows 'unsafe-eval' — eval()/Function()/similar are permitted.");
            }
            if (containsToken(lower, "*") && !lower.contains("'strict-dynamic'")) {
                highSeverity.add("script-src/default-src includes a bare wildcard '*' host source.");
            }
            if (containsToken(lower, "http:") || containsToken(lower, "https:") || containsToken(lower, "data:")) {
                highSeverity.add("script-src/default-src allows a scheme-only source (http:, https:, or data:) — "
                        + "equivalent to allowing scripts from almost anywhere.");
            }
        }

        String objectSrc = directives.getOrDefault("object-src", directives.get("default-src"));
        if (objectSrc == null || !objectSrc.toLowerCase(Locale.ROOT).contains("'none'")) {
            highSeverity.add("object-src (or default-src) does not restrict to 'none' — plugin-based content "
                    + "(Flash/Java applets) is not blocked, a common CSP-bypass vector.");
        }

        if (!directives.containsKey("base-uri")) {
            highSeverity.add("No base-uri directive — a successful injection could rewrite <base href> to redirect "
                    + "relative script/resource loads to an attacker-controlled host.");
        }

        if (highSeverity.isEmpty()) {
            // Deliberately doesn't append the raw CSP value here — it can be
            // very long, and the header itself is already highlighted in the
            // response pane (see headerLine below), so repeating it in the
            // reason text would just bloat every PASS row/screenshot.
            return ValidationResult.pass(
                    "No high-severity issues found by this heuristic (still recommend a manual pass "
                            + "through csp-evaluator.withgoogle.com for full parity).",
                    headerLine);
        }

        return ValidationResult.fail(String.join("\n", highSeverity), headerLine);
    }

    private boolean containsToken(String directiveValueLower, String token) {
        for (String part : directiveValueLower.split("\\s+")) {
            if (part.equals(token)) return true;
        }
        return false;
    }

    private Map<String, String> parseDirectives(String cspValue) {
        Map<String, String> map = new java.util.LinkedHashMap<>();
        for (String directive : cspValue.split(";")) {
            String trimmed = directive.trim();
            if (trimmed.isEmpty()) continue;
            int sp = trimmed.indexOf(' ');
            String key = (sp < 0 ? trimmed : trimmed.substring(0, sp)).toLowerCase(Locale.ROOT);
            String value = sp < 0 ? "" : trimmed.substring(sp + 1).trim();
            map.put(key, value);
        }
        return map;
    }
}
