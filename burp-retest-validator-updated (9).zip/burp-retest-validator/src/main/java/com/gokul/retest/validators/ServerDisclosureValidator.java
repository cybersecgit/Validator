package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.HeaderUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

public class ServerDisclosureValidator implements Validator {

    // Matches a product name followed by a version number, e.g. "Apache/2.4.41", "PHP/7.4.3"
    private static final Pattern VERSION_PATTERN = Pattern.compile(".*/\\d+(\\.\\d+)+.*");

    private static final String[] HEADERS_TO_CHECK = {
        "Server", "X-Powered-By", "X-AspNet-Version", "X-AspNetMvc-Version"
    };

    @Override
    public String name() { return "Server/Tech Version Disclosure"; }

    @Override
    public String category() { return "Information Disclosure"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        List<HttpHeader> headers = response.headers();

        for (String headerName : HEADERS_TO_CHECK) {
            Optional<List<String>> dup = HeaderUtils.duplicateWithDifferentValues(headers, headerName);
            if (dup.isPresent()) {
                return ValidationResult.fail(
                        "Duplicate " + headerName + " headers with different values: " + String.join("\n", dup.get()),
                        dup.get().toArray(new String[0]));
            }
        }

        StringBuilder findingsSummary = new StringBuilder();
        List<String> versionedLines = new ArrayList<>();
        List<String> presentLines = new ArrayList<>();

        for (String headerName : HEADERS_TO_CHECK) {
            headers.stream()
                    .filter(h -> h.name().equalsIgnoreCase(headerName))
                    .findFirst()
                    .ifPresent(h -> {
                        String line = h.name() + ": " + h.value();
                        boolean versioned = VERSION_PATTERN.matcher(h.value()).matches();
                        findingsSummary.append(line)
                                .append(versioned ? " (VERSIONED)" : " (present, no version string)")
                                .append("\n");
                        presentLines.add(line);
                        if (versioned) versionedLines.add(line);
                    });
        }

        if (presentLines.isEmpty()) {
            return ValidationResult.pass("No Server/X-Powered-By/framework version headers present.");
        }
        String summary = findingsSummary.toString().stripTrailing();
        if (!versionedLines.isEmpty()) {
            return ValidationResult.fail(summary, versionedLines.toArray(new String[0]));
        }
        return ValidationResult.inconclusive(summary, presentLines.toArray(new String[0]));
    }
}
