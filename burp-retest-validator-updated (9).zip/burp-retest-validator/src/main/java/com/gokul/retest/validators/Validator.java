package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;

/**
 * Contract every retest check implements.
 *
 * Add a new finding type by writing a new class that implements this
 * interface and registering it in RetestTabUI.ALL_VALIDATORS — nothing
 * else in the extension needs to change.
 */
public interface Validator {

    /** Short name shown as a checkbox label in the UI, e.g. "Missing HSTS". */
    String name();

    /** OWASP/finding category tag, purely for the evidence file header. */
    String category();

    /**
     * Inspect the replayed request/response and decide pass/fail.
     * Implementations should never throw — catch and return a FAIL
     * result with the exception message in the detail field instead,
     * so one bad validator can't abort the whole run.
     */
    ValidationResult validate(HttpRequest request, HttpResponse response);
}
