package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.HeaderUtils;

import java.util.List;
import java.util.Optional;

/**
 * X-XSS-Protection is obsolete and, on modern browsers, its legacy
 * "1; mode=block" behavior has been shown to introduce XSS vectors of
 * its own (the browser's filter could be abused for info leaks). The
 * only two acceptable states on retest are:
 *   - header absent entirely, or
 *   - X-XSS-Protection: 0 (explicitly disabled)
 * Any other value (e.g. "1", "1; mode=block") is a fail.
 */
public class XXssProtectionValidator implements Validator {

    @Override
    public String name() { return "Obsolete X-XSS-Protection Header"; }

    @Override
    public String category() { return "Security Misconfiguration — Headers"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        List<HttpHeader> headers = response.headers();

        Optional<List<String>> dup = HeaderUtils.duplicateWithDifferentValues(headers, "X-XSS-Protection");
        if (dup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate X-XSS-Protection headers with different values: " + String.join("\n", dup.get()),
                    dup.get().toArray(new String[0]));
        }

        Optional<HttpHeader> hdr = HeaderUtils.findFirst(headers, "X-XSS-Protection");
        if (hdr.isEmpty()) {
            return ValidationResult.pass("X-XSS-Protection header is absent (acceptable — header is obsolete).");
        }

        String headerLine = HeaderUtils.line(hdr.get());
        String value = hdr.get().value().trim();

        if (value.equals("0")) {
            return ValidationResult.pass("X-XSS-Protection explicitly set to 0 (disabled).", headerLine);
        }

        return ValidationResult.fail(
                "X-XSS-Protection is present with a non-zero value (\"" + value + "\") — "
                        + "should be removed entirely or set to 0.", headerLine);
    }
}
