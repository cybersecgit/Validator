package com.gokul.retest;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import com.gokul.retest.util.TableFormatter;
import com.gokul.retest.validators.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

/**
 * Renders request + response as side-by-side text panels and saves the
 * result as a PNG — one per finding, with the relevant response line(s)
 * highlighted so the screenshot alone shows the issue, matching how
 * testers already evidence findings in reports.
 *
 * Rendering approach: build the panel inside an off-screen JWindow
 * (positioned well outside the visible desktop) so fonts/layout resolve
 * correctly via a real native peer, then paint it into a BufferedImage.
 * Uses only public Swing APIs — no dependency on Burp's internal
 * editor/rendering components.
 *
 * Body handling: HEADERS are always shown in full (that's almost always
 * what a header-based finding needs), while the BODY is truncated to a
 * short preview so the screenshot stays readable without zooming — the
 * full body is still available in the saved .html evidence file.
 *
 * Colors: every text component below has its foreground/background set
 * explicitly (never left to inherit from the current look-and-feel).
 * Burp's own dark theme sets a light/white default label and text-area
 * foreground; painted onto this class's light pastel banner/highlight
 * backgrounds, inherited text would render as pale-on-pale and be close
 * to unreadable — exactly what happened before this was explicit.
 */
public class ScreenshotCapture {

    private static final int MAX_BODY_LINES = 5;
    // Heuristic cap on raw characters shown from the body, independent of
    // MAX_BODY_LINES: a minified/compact body (common for HTML/JSON) can be
    // one giant logical line with no '\n' at all, which line-counting alone
    // wouldn't catch — it would then word-wrap into dozens of visual rows
    // in the screenshot. ~100 chars/line * MAX_BODY_LINES is a rough but
    // effective backstop for a 700px-wide, 12pt monospaced pane.
    private static final int MAX_BODY_CHARS = MAX_BODY_LINES * 100;
    private static final int MAX_HEADER_ONLY_LINES = 250; // fallback if no header/body separator is found
    // Cap on the banner's reason text: enough room for a short general
    // overview (a few bullet-style lines), but short of ever embedding an
    // entire raw header value (e.g. a full CSP policy) — that stays out of
    // the banner and lives in the saved .html evidence table instead.
    private static final int MAX_BANNER_REASON_CHARS = 480;
    private static final int PANE_WIDTH = 700;
    private static final Font MONO_FONT = new Font(Font.MONOSPACED, Font.PLAIN, 12);

    private static final Color PASS_COLOR = new Color(214, 245, 214);
    private static final Color FAIL_COLOR = new Color(255, 214, 214);
    private static final Color INCONCLUSIVE_COLOR = new Color(255, 244, 214);
    private static final Color HIGHLIGHT_COLOR = new Color(255, 235, 59); // yellow marker
    private static final Color TEXT_COLOR = Color.BLACK;
    private static final Color SUBTITLE_TEXT_COLOR = new Color(70, 70, 70);

    // Short, unique-enough codes for filenames (see capturePerFinding()).
    // Anything not in this map falls back to an auto-derived short code.
    private static final Map<Class<? extends Validator>, String> SHORT_CODES = Map.ofEntries(
            Map.entry(HstsValidator.class, "HSTS"),
            Map.entry(ClickjackingValidator.class, "XFO"),
            Map.entry(CorsValidator.class, "CORS"),
            Map.entry(ServerDisclosureValidator.class, "SRV"),
            Map.entry(XXssProtectionValidator.class, "XXSS"),
            Map.entry(CspValidator.class, "CSP"),
            Map.entry(MissingSecurityHeadersValidator.class, "HDRS"),
            Map.entry(CookieFlagsValidator.class, "COOKIE"),
            Map.entry(SensitiveGetParamValidator.class, "GETPII"),
            Map.entry(StackTraceDisclosureValidator.class, "STACK")
    );

    private final Path outputDir;

    public ScreenshotCapture(Path outputDir) throws IOException {
        this.outputDir = outputDir;
        Files.createDirectories(outputDir);
    }

    /**
     * Produces one PNG for a single validator's result, with its
     * highlightTexts() marked in the response pane. Filename is
     * "<host>_p<port>_<code>.png" — fixed per host/port/finding, not
     * per run, so re-running Validate/Save Artifacts overwrites the
     * previous screenshot for that finding rather than piling up
     * timestamped files.
     */
    public Path capturePerFinding(HttpRequest request,
                                   HttpResponse response,
                                   Validator validator,
                                   ValidationResult result,
                                   boolean redact) throws IOException {

        String safeHost = safeHost(request.httpService().host());
        int port = request.httpService().port();
        String code = shortCode(validator);
        Path file = outputDir.resolve(safeHost + "_p" + port + "_" + code + ".png");

        String reqText = redact ? Redactor.redact(request.toString()) : request.toString();
        String resText = redact ? Redactor.redact(response.toString()) : response.toString();
        reqText = truncateBody(reqText);
        resText = truncateBody(resText);

        Color bannerColor = switch (result.status()) {
            case PASS -> PASS_COLOR;
            case FAIL -> FAIL_COLOR;
            case INCONCLUSIVE -> INCONCLUSIVE_COLOR;
        };

        JTextArea reqArea = buildTextArea(reqText);
        JTextArea resArea = buildTextArea(resText);

        // Highlight the relevant line(s) in the response pane.
        int highlightedCount = 0;
        for (String needle : result.highlightTexts()) {
            highlightedCount += highlight(resArea, needle);
        }

        JPanel reqPane = titledPane("REQUEST", reqArea, new Color(235, 244, 255), null);
        String resSubtitle = highlightedCount > 0
                ? null
                : "(no matching header line — see status/detail below)";
        JPanel resPane = titledPane("RESPONSE", resArea, new Color(235, 255, 238), resSubtitle);

        JPanel body = new JPanel(new GridLayout(1, 2, 6, 0));
        body.setBackground(Color.WHITE);
        body.add(reqPane);
        body.add(resPane);

        int width = PANE_WIDTH * 2 + 24;

        // Banner: bold "STATUS — Finding Name" title line, plus a wrapped
        // general-overview reason underneath (capped — see
        // MAX_BANNER_REASON_CHARS — so a validator with a very long detail,
        // e.g. an entire raw header value, never blows up the banner).
        String bannerSummary = summarizeForBanner(result.detail());
        JPanel bannerPanel = new JPanel();
        bannerPanel.setLayout(new BoxLayout(bannerPanel, BoxLayout.Y_AXIS));
        bannerPanel.setOpaque(true);
        bannerPanel.setBackground(bannerColor);
        bannerPanel.setBorder(new EmptyBorder(6, 8, 6, 8));

        JLabel titleLabel = new JLabel(result.shortStatusLabel() + " — " + validator.name());
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 13f));
        titleLabel.setForeground(TEXT_COLOR);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        bannerPanel.add(titleLabel);

        int bannerWrappedLines = 0;
        if (!bannerSummary.isBlank()) {
            JTextArea reasonArea = new JTextArea(bannerSummary);
            reasonArea.setEditable(false);
            reasonArea.setOpaque(false);
            reasonArea.setForeground(TEXT_COLOR);
            reasonArea.setLineWrap(true);
            reasonArea.setWrapStyleWord(true);
            reasonArea.setFont(reasonArea.getFont().deriveFont(Font.PLAIN, 12f));
            reasonArea.setAlignmentX(Component.LEFT_ALIGNMENT);
            reasonArea.setBorder(new EmptyBorder(3, 0, 0, 0));
            bannerPanel.add(reasonArea);
            // Rough char-per-line estimate for a proportional 12pt font at
            // (width - horizontal padding) — only needed to size the PNG
            // tall enough; doesn't need to be pixel-exact.
            int approxCharsPerLine = Math.max(20, (width - 16) / 7);
            bannerWrappedLines = TableFormatter.wrap(bannerSummary, approxCharsPerLine).size();
        }

        JPanel root = new JPanel(new BorderLayout(0, 4));
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(6, 6, 6, 6));
        root.add(bannerPanel, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);

        int lineCount = Math.max(countLines(reqText), countLines(resText));
        int bannerExtra = bannerWrappedLines * 16 + (bannerWrappedLines > 0 ? 8 : 0);
        int height = clamp(lineCount * 16 + 130 + bannerExtra, 320, 3000);

        BufferedImage image = renderOffscreen(root, width, height);
        ImageIO.write(image, "png", file.toFile());
        return file;
    }

    /** Trims/collapses a validator's detail text down to a screenshot-friendly overview. */
    private String summarizeForBanner(String detail) {
        if (detail == null) return "";
        String cleaned = detail.trim();
        if (cleaned.length() <= MAX_BANNER_REASON_CHARS) return cleaned;
        return cleaned.substring(0, MAX_BANNER_REASON_CHARS)
                + "\n… [truncated for brevity]";
    }

    private String shortCode(Validator validator) {
        String code = SHORT_CODES.get(validator.getClass());
        if (code != null) return code;
        // Fallback for any validator not in the map above: derive a short
        // code from the class name so filenames stay short either way.
        String simple = validator.getClass().getSimpleName().replace("Validator", "");
        return simple.length() > 8 ? simple.substring(0, 8).toUpperCase() : simple.toUpperCase();
    }

    /** Sanitizes a host/IP for safe use in a filename. */
    private String safeHost(String host) {
        String cleaned = host.toLowerCase().replaceAll("[^a-z0-9.-]", "_");
        if (cleaned.length() <= 60) return cleaned;
        String truncated = cleaned.substring(0, 50);
        String hash = Integer.toHexString(cleaned.hashCode());
        return truncated + "_" + hash;
    }

    private BufferedImage renderOffscreen(JComponent root, int width, int height) {
        JWindow window = new JWindow();
        window.setLayout(new BorderLayout());
        window.add(root, BorderLayout.CENTER);
        window.setSize(width, height);
        // Positioned far outside any real desktop coordinates so it
        // doesn't visibly flash, while still getting a native peer so
        // Swing lays out and paints text/fonts correctly.
        window.setLocation(-20000, -20000);
        window.setVisible(true);
        window.validate();

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, height);
        window.printAll(g);
        g.dispose();
        window.dispose();
        return image;
    }

    /** Highlights all occurrences of `needle` in the text area. Returns how many were found. */
    private int highlight(JTextArea area, String needle) {
        if (needle == null || needle.isBlank()) return 0;
        String text = area.getText();
        Highlighter highlighter = area.getHighlighter();
        Highlighter.HighlightPainter painter = new DefaultHighlighter.DefaultHighlightPainter(HIGHLIGHT_COLOR);

        int count = 0;
        int idx = 0;
        while ((idx = text.indexOf(needle, idx)) >= 0) {
            try {
                highlighter.addHighlight(idx, idx + needle.length(), painter);
                count++;
            } catch (BadLocationException ignored) {
                // Shouldn't happen since indices come from the same text.
            }
            idx += needle.length();
        }
        return count;
    }

    private JTextArea buildTextArea(String text) {
        JTextArea area = new JTextArea(text);
        area.setFont(MONO_FONT);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(false);
        area.setBorder(new EmptyBorder(6, 6, 6, 6));
        area.setSize(PANE_WIDTH, Short.MAX_VALUE);
        area.setOpaque(true);
        area.setBackground(Color.WHITE);
        area.setForeground(TEXT_COLOR);
        area.setSelectionColor(HIGHLIGHT_COLOR);
        area.setSelectedTextColor(TEXT_COLOR);
        return area;
    }

    private JPanel titledPane(String title, JTextArea area, Color headerColor, String subtitle) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(headerColor);
        JLabel header = new JLabel(title);
        header.setBorder(new EmptyBorder(4, 8, subtitle == null ? 4 : 0, 8));
        header.setFont(header.getFont().deriveFont(Font.BOLD));
        header.setForeground(TEXT_COLOR);
        headerPanel.add(header, BorderLayout.NORTH);
        if (subtitle != null) {
            JLabel sub = new JLabel(subtitle);
            sub.setBorder(new EmptyBorder(0, 8, 4, 8));
            sub.setFont(sub.getFont().deriveFont(Font.ITALIC, 11f));
            sub.setForeground(SUBTITLE_TEXT_COLOR);
            headerPanel.add(sub, BorderLayout.SOUTH);
        }

        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(area, BorderLayout.CENTER);
        return panel;
    }

    /**
     * Keeps the header block of a raw HTTP message intact (headers are
     * almost always what these findings hinge on) and truncates only the
     * body portion, appending a note that the full body lives in the
     * saved .html evidence file. Falls back to a flat line-count
     * truncation if no blank-line header/body separator is found (e.g. a
     * malformed or headers-only message).
     *
     * Truncates by BOTH real newline count and raw character count — a
     * minified/compact body (no embedded '\n' at all) would otherwise
     * sail through the line-count check and still word-wrap into dozens
     * of visual rows once rendered.
     */
    private String truncateBody(String rawHttpMessage) {
        // Normalize CRLF to LF first — Montoya's toString() preserves the
        // real HTTP wire format ("\r\n" line endings), so the true
        // header/body separator is "\r\n\r\n". Searching for a bare "\n\n"
        // against that never matches (there's a '\r' between the two
        // '\n's), which silently sent every message through the "no
        // separator found" flat-truncation fallback below instead of the
        // real 5-line body cap.
        rawHttpMessage = rawHttpMessage.replace("\r\n", "\n");
        int sep = rawHttpMessage.indexOf("\n\n");
        if (sep < 0) {
            return truncateFlat(rawHttpMessage, MAX_HEADER_ONLY_LINES);
        }

        String headerBlock = rawHttpMessage.substring(0, sep + 2);
        String bodyBlock = rawHttpMessage.substring(sep + 2);

        String[] bodyLines = bodyBlock.split("\n", -1);
        boolean truncatedByLines = bodyLines.length > MAX_BODY_LINES;
        String candidateBody;
        if (truncatedByLines) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < MAX_BODY_LINES; i++) sb.append(bodyLines[i]).append("\n");
            candidateBody = sb.toString();
        } else {
            candidateBody = bodyBlock;
        }

        boolean truncatedByChars = candidateBody.length() > MAX_BODY_CHARS;
        if (truncatedByChars) {
            candidateBody = candidateBody.substring(0, MAX_BODY_CHARS);
        }

        if (!truncatedByLines && !truncatedByChars) {
            return rawHttpMessage; // whole body already fits comfortably
        }

        StringBuilder sb = new StringBuilder(headerBlock).append(candidateBody);
        if (!candidateBody.endsWith("\n")) sb.append("\n");
        sb.append("... [truncated for brevity]");
        return sb.toString();
    }

    private String truncateFlat(String text, int maxLines) {
        String[] lines = text.split("\n", -1);
        if (lines.length <= maxLines) return text;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < maxLines; i++) sb.append(lines[i]).append("\n");
        sb.append("... [truncated, ").append(lines.length - maxLines).append(" more lines]");
        return sb.toString();
    }

    private int countLines(String text) {
        return text.split("\n", -1).length;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
