package com.gokul.retest;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.proxy.ProxyHttpRequestResponse;
import com.gokul.retest.util.TableFormatter;
import com.gokul.retest.validators.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.HierarchyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class RetestTabUI {

    // Registered validators — add a new finding-type check here and it
    // shows up as a checkbox automatically. Nothing else needs editing,
    // except CorsValidator, which needs a MontoyaApi reference because it
    // sends its own probe requests (see runValidation()).
    private final List<Validator> allValidators;

    private static final Color PASS_COLOR = new Color(223, 245, 223);
    private static final Color FAIL_COLOR = new Color(249, 214, 214);
    private static final Color REVIEW_COLOR = new Color(253, 241, 207);

    private final MontoyaApi api;
    private final JPanel root = new JPanel(new BorderLayout(8, 8));
    private final DefaultTableModel historyModel =
            new DefaultTableModel(new Object[]{"#", "Method", "URL", "Status"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final JTable historyTable = new JTable(historyModel);
    private final TableRowSorter<DefaultTableModel> historySorter = new TableRowSorter<>(historyModel);
    private final JTextField searchField = new JTextField();
    private final Map<Validator, JCheckBox> validatorCheckboxes = new java.util.LinkedHashMap<>();
    private final JCheckBox selectAllCheckbox = new JCheckBox("Select All");
    private final JCheckBox redactCheckbox = new JCheckBox("Redact Sensitive Values", true);
    private final JTextField outputDirField = new JTextField();

    // Results: a status/log line above a colored STATUS/CONTROL NAME/REASON table.
    private final JTextArea statusArea = new JTextArea();
    private final DefaultTableModel resultsTableModel =
            new DefaultTableModel(new Object[]{"STATUS", "CONTROL NAME", "REASON"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final JTable resultsTable = new JTable(resultsTableModel);

    private Path outputDir = Path.of(System.getProperty("user.home"), "retest-evidence");
    private List<ProxyHttpRequestResponse> currentHistory = new ArrayList<>();

    public RetestTabUI(MontoyaApi api) {
        this.api = api;
        this.allValidators = List.of(
                new HstsValidator(),
                new ClickjackingValidator(),
                new CorsValidator(api),
                new ServerDisclosureValidator(),
                new XXssProtectionValidator(),
                new CspValidator(),
                new MissingSecurityHeadersValidator(),
                new CookieFlagsValidator(),
                new SensitiveGetParamValidator(),
                new StackTraceDisclosureValidator()
        );
        outputDirField.setText(outputDir.toString());
        buildUI();
    }

    public Component getComponent() { return root; }

    private void buildUI() {
        // --- Top: output folder picker + search + proxy history table ---
        JPanel top = new JPanel(new BorderLayout(4, 4));

        JPanel folderRow = new JPanel(new BorderLayout(4, 0));
        folderRow.setBorder(BorderFactory.createTitledBorder("Artifact output folder"));
        outputDirField.setEditable(false);
        JButton chooseFolderBtn = new JButton("Choose Folder...");
        chooseFolderBtn.addActionListener(e -> chooseOutputFolder());
        folderRow.add(outputDirField, BorderLayout.CENTER);
        folderRow.add(chooseFolderBtn, BorderLayout.EAST);

        JButton refreshBtn = new JButton("Refresh from Proxy History");
        refreshBtn.addActionListener(e -> refreshHistory());

        JButton viewBtn = new JButton("View");
        viewBtn.setToolTipText("View the raw request/response of the selected row "
                + "(useful when several entries share a URL but differ in body)");
        viewBtn.addActionListener(e -> viewSelected());

        JPanel searchRow = new JPanel(new BorderLayout(4, 0));
        searchRow.setBorder(BorderFactory.createTitledBorder("Search proxy history"));
        searchRow.add(new JLabel(" \uD83D\uDD0D "), BorderLayout.WEST); // magnifying glass
        searchRow.add(searchField, BorderLayout.CENTER);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { applySearchFilter(); }
            @Override public void removeUpdate(DocumentEvent e) { applySearchFilter(); }
            @Override public void changedUpdate(DocumentEvent e) { applySearchFilter(); }
        });

        JPanel refreshViewRow = new JPanel(new GridLayout(1, 2, 4, 0));
        refreshViewRow.add(refreshBtn);
        refreshViewRow.add(viewBtn);

        JPanel topButtons = new JPanel();
        topButtons.setLayout(new BoxLayout(topButtons, BoxLayout.Y_AXIS));
        topButtons.add(folderRow);
        topButtons.add(searchRow);
        topButtons.add(refreshViewRow);

        top.add(topButtons, BorderLayout.NORTH);
        historyTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        historyTable.setRowSorter(historySorter);
        sizeHistoryColumns();
        historyTable.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) viewSelected();
            }
        });
        top.add(new JScrollPane(historyTable), BorderLayout.CENTER);

        // --- Middle: validator checkboxes + options ---
        // Every finding checkbox lives in ONE BoxLayout column
        // (optionsList) so they share exactly the same left edge — the
        // column's own width is naturally the widest row (the longest
        // checkbox label), and everything else left-aligns within that.
        // optionsList itself is then centered as a single block within the
        // wider "Findings to validate" panel. "Select All" and "Redact"
        // sit together in one row below the list (rather than each on
        // their own line with extra spacing) to keep this panel compact —
        // it's placed above the proxy history pane, so a taller findings
        // panel directly steals rows from that list.
        JPanel middle = new JPanel();
        middle.setLayout(new BoxLayout(middle, BoxLayout.Y_AXIS));
        middle.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Findings to validate"),
                new EmptyBorder(10, 28, 10, 28))); // "tab space" gap from the border on every side

        JPanel optionsList = new JPanel();
        optionsList.setLayout(new BoxLayout(optionsList, BoxLayout.Y_AXIS));

        for (Validator v : allValidators) {
            JCheckBox cb = new JCheckBox(v.name());
            // Default: everything unselected except the redact checkbox
            // below — the user opts in to whichever findings they want.
            cb.setSelected(false);
            cb.setAlignmentX(Component.LEFT_ALIGNMENT);
            validatorCheckboxes.put(v, cb);
            optionsList.add(cb);
        }
        optionsList.setAlignmentX(Component.CENTER_ALIGNMENT);
        middle.add(optionsList);

        selectAllCheckbox.setToolTipText("Select/deselect every finding above");
        selectAllCheckbox.addActionListener(e -> {
            boolean selected = selectAllCheckbox.isSelected();
            for (JCheckBox cb : validatorCheckboxes.values()) cb.setSelected(selected);
        });
        JPanel controlsRow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        controlsRow.add(selectAllCheckbox);
        redactCheckbox.setToolTipText("Redact sensitive header values (Cookie, Authorization, etc.) in saved artifacts");
        controlsRow.add(redactCheckbox);
        controlsRow.setAlignmentX(Component.CENTER_ALIGNMENT);
        middle.add(Box.createVerticalStrut(4));
        middle.add(controlsRow);

        JButton runBtn = new JButton("Validate");
        runBtn.setToolTipText("Replay the selected request and run the checked findings against it");
        runBtn.addActionListener(e -> runValidation());
        JButton saveBtn = new JButton("Save Artifacts");
        saveBtn.setToolTipText("Save evidence (.html) and one screenshot per finding from the last run");
        saveBtn.addActionListener(e -> saveArtifacts());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttons.add(runBtn);
        buttons.add(saveBtn);
        buttons.setAlignmentX(Component.CENTER_ALIGNMENT);
        middle.add(Box.createVerticalStrut(10));
        middle.add(buttons);

        // Findings panel is placed in BorderLayout.SOUTH below (not a
        // JSplitPane) so it always sizes to exactly its own preferred
        // height — no leftover blank space, and no manual divider
        // dragging needed. If more finding checkboxes are added later,
        // this grows on its own and the proxy history area above shrinks
        // to make room automatically.
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.add(top, BorderLayout.CENTER);
        leftPanel.add(middle, BorderLayout.SOUTH);

        // --- Right: results ---
        statusArea.setEditable(false);
        statusArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        statusArea.setLineWrap(true);
        statusArea.setWrapStyleWord(true);
        statusArea.setRows(4);

        resultsTable.setRowSelectionAllowed(false);
        resultsTable.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        resultsTable.getColumnModel().getColumn(0).setPreferredWidth(70);
        sizeResultsNameColumn();
        WrappingCellRenderer wrappingRenderer = new WrappingCellRenderer();
        for (int c = 0; c < resultsTable.getColumnCount(); c++) {
            resultsTable.getColumnModel().getColumn(c).setCellRenderer(wrappingRenderer);
        }
        // Recompute row heights any time the table's actual pixel size
        // changes — not just once, right after Validate populates it.
        // Column widths (specifically REASON, the auto-resizing last
        // column) can keep settling asynchronously for a bit after that —
        // exactly what a manual divider drag was triggering "for free"
        // before, which is why that always fixed row 0's height but a
        // single deferred calculation right after populating didn't.
        // Self-correcting on every resize removes the dependency on that
        // one moment being right.
        resultsTable.addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) {
                adjustResultsRowHeights();
            }
        });

        JPanel resultsPanel = new JPanel(new BorderLayout(0, 4));
        resultsPanel.add(new JScrollPane(statusArea), BorderLayout.NORTH);
        resultsPanel.add(new JScrollPane(resultsTable), BorderLayout.CENTER);
        resultsPanel.setBorder(BorderFactory.createTitledBorder("Results / Evidence Preview"));

        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, resultsPanel);
        // 45/55 split, both on first layout and as the window is resized
        // afterwards.
        mainSplit.setResizeWeight(0.45);
        setInitialDividerProportion(mainSplit, 0.45);

        root.add(mainSplit, BorderLayout.CENTER);

        statusArea.setText("Click 'Refresh from Proxy History' to load requests, tick the findings to check "
                + "(or use 'Select All'), select a row, then 'Validate'.");
    }

    /**
     * JSplitPane.setDividerLocation(double) needs the pane to already have
     * a valid on-screen size to compute a meaningful pixel position — call
     * it before the pane is shown and it has nothing to go on. This defers
     * the call to the moment the pane actually becomes visible, so the
     * initial 40/60 split is honored on first paint rather than only after
     * the user manually resizes something.
     */
    private void setInitialDividerProportion(JSplitPane splitPane, double proportion) {
        splitPane.addHierarchyListener(e -> {
            if ((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && splitPane.isShowing()) {
                splitPane.setDividerLocation(proportion);
            }
        });
    }

    /**
     * Sizes the "#"/"Method"/"Status" proxy-history columns to just fit
     * their header text (they never need to show more than that). Both
     * min AND max width are locked to that fitted size — max alone isn't
     * enough, since JTable's default column-resize behavior will still
     * *shrink* every column (including capped ones) proportionally
     * whenever the table is narrower than the sum of its columns'
     * preferred widths, which is what was truncating "Method" before.
     * Locking min = max = preferred makes these three columns immune to
     * that, leaving the URL column (which has no such lock) to absorb
     * all of the growing or shrinking.
     */
    private void sizeHistoryColumns() {
        FontMetrics fm = historyTable.getTableHeader().getFontMetrics(historyTable.getTableHeader().getFont());
        int pad = 34; // header padding + sort-arrow allowance
        fitColumnToText(historyTable, 0, "#", fm, pad);
        fitColumnToText(historyTable, 1, "Method", fm, pad);
        fitColumnToText(historyTable, 3, "Status", fm, pad);
        historyTable.getColumnModel().getColumn(2).setPreferredWidth(600); // URL: gets the rest
    }

    /**
     * Sizes the results table's CONTROL NAME column to fit "Missing
     * Clickjacking" (the widest common finding-name prefix) and locks it
     * there the same way sizeHistoryColumns() does, so the REASON column
     * (already flexible via AUTO_RESIZE_LAST_COLUMN) gets whatever space
     * is left over instead of CONTROL NAME growing to fit the longest
     * full finding name.
     */
    private void sizeResultsNameColumn() {
        FontMetrics fm = resultsTable.getFontMetrics(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        fitColumnToText(resultsTable, 1, "Missing Clickjacking", fm, 24);
    }

    private void fitColumnToText(JTable table, int columnIndex, String text, FontMetrics fm, int padding) {
        int width = fm.stringWidth(text) + padding;
        TableColumn column = table.getColumnModel().getColumn(columnIndex);
        column.setPreferredWidth(width);
        column.setMinWidth(width);
        column.setMaxWidth(width);
    }

    /** Table cell renderer that word-wraps its text, colors the row background by STATUS, and draws a thin grey separator between rows (and columns) so adjacent same-colored rows are still visually distinct. */
    private static class WrappingCellRenderer extends JTextArea implements TableCellRenderer {
        private static final Border CELL_BORDER = BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 1, new Color(190, 190, 190)),
                new EmptyBorder(4, 6, 4, 6));

        WrappingCellRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
            setEditable(false);
            setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
            setBorder(CELL_BORDER);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                         boolean hasFocus, int row, int column) {
            setText(value == null ? "" : value.toString());
            setFont(column == 0
                    ? getFont().deriveFont(Font.BOLD)
                    : getFont().deriveFont(Font.PLAIN));
            String status = String.valueOf(table.getValueAt(row, 0));
            setBackground(statusColor(status));
            setForeground(Color.BLACK);
            return this;
        }
    }

    private static Color statusColor(String status) {
        return switch (status) {
            case "PASS" -> PASS_COLOR;
            case "FAIL" -> FAIL_COLOR;
            case "REVIEW" -> REVIEW_COLOR;
            default -> Color.WHITE;
        };
    }

    /** Recomputes each results-table row's height so wrapped REASON text isn't clipped. */
    /**
     * Recomputes each results-table row's height so wrapped REASON text
     * isn't clipped.
     *
     * Deliberately does NOT ask Swing for the wrapped JTextArea's
     * getPreferredSize() — that relies on the shared renderer's internal
     * text-layout cache being valid at exactly the moment it's queried,
     * and in practice that was unreliable (row 0's last wrapped line kept
     * getting clipped regardless of warm-up passes). Instead this counts
     * wrapped lines itself with TableFormatter.wrap() — the same
     * word-wrap helper used for the screenshot banner — and computes an
     * exact pixel height from that. Because the renderer's font is
     * monospaced, every character is exactly fm.charWidth('M') pixels
     * wide, so "how many characters fit before wrapping" can be computed
     * precisely rather than estimated, making this deterministic instead
     * of dependent on Swing's layout timing.
     */
    private boolean adjustingRowHeights = false;

    private void adjustResultsRowHeights() {
        // setRowHeight() below changes the table's own height, which can
        // itself fire another componentResized event (see the listener
        // registered in buildUI()) — guard against re-entering this method
        // from that nested callback; the values will already be correct
        // once the outer call finishes, and unlike the earlier single-shot
        // invokeLater fix, that outer call plus the *next* genuine resize
        // (from the REASON column's own async width settling) reliably
        // converges to the right answer without needing a manual nudge.
        if (adjustingRowHeights) return;
        adjustingRowHeights = true;
        try {
            // Force the whole tab's layout (split panes, scroll panes,
            // table) to settle synchronously before reading any column
            // width below, on the off chance it hasn't already.
            root.validate();

            Font cellFont = new Font(Font.MONOSPACED, Font.PLAIN, 12);
            FontMetrics fm = resultsTable.getFontMetrics(cellFont);
            int lineHeight = fm.getHeight();
            int charWidth = Math.max(1, fm.charWidth('M'));
            // WrappingCellRenderer's border: EmptyBorder(4,6,4,6) + a 1px matte line.
            int horizontalPadding = 6 + 6 + 1;
            int verticalPadding = 4 + 4 + 1;

            for (int row = 0; row < resultsTable.getRowCount(); row++) {
                int maxLines = 1;
                for (int col = 0; col < resultsTable.getColumnCount(); col++) {
                    Object value = resultsTable.getValueAt(row, col);
                    String text = value == null ? "" : value.toString();
                    int colWidth = resultsTable.getColumnModel().getColumn(col).getWidth();
                    if (colWidth <= 0) colWidth = 200;
                    int textWidth = Math.max(charWidth, colWidth - horizontalPadding);
                    int charsPerLine = Math.max(1, textWidth / charWidth);
                    int lines = TableFormatter.wrap(text, charsPerLine).size();
                    maxLines = Math.max(maxLines, lines);
                }
                // A little slack on top of the exact calculation to absorb
                // any minor rounding/hinting differences between our
                // character-width math and the platform's actual glyph
                // rendering.
                resultsTable.setRowHeight(row, maxLines * lineHeight + verticalPadding + 4);
            }
        } finally {
            adjustingRowHeights = false;
        }
    }

    /** Filters the proxy history table to rows whose method/URL/status match the search text (case-insensitive). */
    private void applySearchFilter() {
        String text = searchField.getText();
        if (text == null || text.isBlank()) {
            historySorter.setRowFilter(null);
            return;
        }
        try {
            historySorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(text)));
        } catch (PatternSyntaxException ex) {
            // Shouldn't happen since the text is quoted, but never let a
            // bad filter throw while the user is mid-typing.
            historySorter.setRowFilter(null);
        }
    }

    private void chooseOutputFolder() {
        JFileChooser chooser = new JFileChooser(outputDir.toFile());
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("Select folder to store retest artifacts");
        int result = chooser.showOpenDialog(root);
        if (result == JFileChooser.APPROVE_OPTION) {
            outputDir = chooser.getSelectedFile().toPath();
            outputDirField.setText(outputDir.toString());
        }
    }

    private void refreshHistory() {
        currentHistory = api.proxy().history();
        searchField.setText("");
        historyModel.setRowCount(0);
        for (int i = 0; i < currentHistory.size(); i++) {
            ProxyHttpRequestResponse item = currentHistory.get(i);
            HttpRequest req = item.finalRequest();
            String status = item.response() != null
                    ? String.valueOf(item.response().statusCode())
                    : "(no response)";
            historyModel.addRow(new Object[]{i + 1, req.method(), req.url(), status});
        }
        resultsTableModel.setRowCount(0);
        statusArea.setText("Loaded " + currentHistory.size() + " proxy history entries.\n"
                + "Search to narrow the list, select a row (double-click, or 'View', to inspect its "
                + "request/response first), tick the findings to check, then click 'Validate'.");
    }

    /** Resolves the table's currently selected row back to its proxy history entry, accounting for the search filter/sorter. */
    private ProxyHttpRequestResponse selectedItem() {
        int viewRow = historyTable.getSelectedRow();
        if (viewRow < 0) return null;
        int modelRow = historyTable.convertRowIndexToModel(viewRow);
        if (modelRow < 0 || modelRow >= currentHistory.size()) return null;
        return currentHistory.get(modelRow);
    }

    /**
     * Opens a read-only viewer for the selected proxy history row's raw
     * request/response. Useful when several entries share the same URL
     * (e.g. repeated POSTs) but carry different bodies, so the tester can
     * confirm they've picked the right one before running Validate.
     */
    private void viewSelected() {
        ProxyHttpRequestResponse item = selectedItem();
        if (item == null) {
            JOptionPane.showMessageDialog(root, "Select a request from the table first.");
            return;
        }
        HttpRequest req = item.finalRequest();
        String reqText = req.toString();
        String resText = item.response() != null ? item.response().toString() : "(no response captured for this entry)";

        JTextPane reqArea = buildHttpMessagePane(reqText);
        JTextPane resArea = buildHttpMessagePane(resText);

        JScrollPane reqScroll = new JScrollPane(reqArea);
        reqScroll.setBorder(BorderFactory.createTitledBorder("Request"));
        JScrollPane resScroll = new JScrollPane(resArea);
        resScroll.setBorder(BorderFactory.createTitledBorder("Response"));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, reqScroll, resScroll);
        split.setResizeWeight(0.5);
        split.setPreferredSize(new Dimension(1000, 600));

        Window owner = SwingUtilities.getWindowAncestor(root);
        JDialog dialog = new JDialog(owner, req.method() + " " + req.url());
        dialog.setModalityType(Dialog.ModalityType.MODELESS);
        dialog.getContentPane().add(split);
        dialog.pack();
        dialog.setLocationRelativeTo(root);
        dialog.setVisible(true);
    }

    // --- HTTP syntax highlighting for the View dialog ---------------------
    // A lightweight approximation of Burp's own message viewer coloring:
    // the request/status line (one uniform color) and header names vs.
    // values (Cookie/Set-Cookie values get their own color). The body is
    // always left as plain, unstyled text — this is a read-only viewer,
    // not an editor, so it only needs to be visually helpful, not
    // exhaustively correct on malformed
    // input.

    private static final Color START_LINE_COLOR = new Color(153, 51, 0);    // request line / HTTP version
    private static final Color HEADER_NAME_COLOR = new Color(0, 0, 170);    // header names
    private static final Color COOKIE_VALUE_COLOR = new Color(0, 128, 0);   // Cookie / Set-Cookie values

    private JTextPane buildHttpMessagePane(String rawMessage) {
        JTextPane pane = new JTextPane();
        pane.setEditable(false);
        pane.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        // Fixed light background/foreground regardless of Burp's own
        // light/dark theme — the highlight colors below (dark orange,
        // navy, etc.) were chosen for a white background and are close to
        // unreadable against a dark one, the same way most code viewers
        // use a fixed "paper" background rather than following the app's
        // theme.
        pane.setBackground(Color.WHITE);
        pane.setForeground(Color.BLACK);
        pane.setCaretColor(Color.BLACK);
        try {
            highlightHttpMessage(pane.getStyledDocument(), rawMessage);
        } catch (Exception ex) {
            // Never let a bug in the highlighter stop the viewer from
            // opening at all — fall back to the raw, unstyled message so
            // there's always something readable rather than nothing.
            javax.swing.text.StyledDocument doc = pane.getStyledDocument();
            try {
                doc.remove(0, doc.getLength());
                doc.insertString(0, rawMessage, null);
            } catch (javax.swing.text.BadLocationException ignored) {
                // Can't happen — 0 is always a valid position on a document we just cleared.
            }
        }
        pane.setCaretPosition(0);
        return pane;
    }

    // Column position within the current output line, tracked across
    // insertStyled()/insertPlain() calls so a long value built up from
    // several separately-styled chunks (a header name + value) still
    // wraps at the right spot — reset per pane build.
    private int viewWrapColumn = 0;
    // Conservative character width for the View dialog's request/response
    // panes (each roughly half of the dialog's default 1000px width, at a
    // 12pt monospaced font) — chosen so text reliably wraps within the
    // visible area rather than being clipped or needing to scroll,
    // slightly under-filling the pane if the dialog is enlarged.
    private static final int VIEW_WRAP_WIDTH = 62;

    /**
     * Colors the request/status line and header names/values (Cookie and
     * Set-Cookie values get their own color); the body — request or
     * response — is always left as plain, unstyled text.
     */
    private void highlightHttpMessage(javax.swing.text.StyledDocument doc, String text) {
        // Normalize CRLF to LF first. Montoya's HttpRequest/HttpResponse
        // .toString() preserves the real HTTP wire format, which uses
        // "\r\n" line endings — so the header/body separator is actually
        // "\r\n\r\n", not "\n\n". Searching for a bare "\n\n" against that
        // never matches (there's a '\r' between the two '\n's).
        text = text.replace("\r\n", "\n");
        viewWrapColumn = 0;
        int sep = text.indexOf("\n\n");
        String headerBlock = sep >= 0 ? text.substring(0, sep) : text;
        String bodyBlock = sep >= 0 ? text.substring(sep) : "";

        String[] headerLines = headerBlock.split("\n", -1);
        for (int i = 0; i < headerLines.length; i++) {
            String line = headerLines[i];
            if (i == 0) {
                insertStartLine(doc, line);
            } else {
                int colon = line.indexOf(':');
                if (colon > 0) {
                    String name = line.substring(0, colon + 1);
                    String value = line.substring(colon + 1);
                    insertStyled(doc, name, styleOf(HEADER_NAME_COLOR, true));
                    boolean isCookie = name.equalsIgnoreCase("Cookie:") || name.equalsIgnoreCase("Set-Cookie:");
                    insertStyled(doc, value, styleOf(isCookie ? COOKIE_VALUE_COLOR : Color.BLACK, false));
                } else {
                    insertPlain(doc, line);
                }
            }
            if (i < headerLines.length - 1) insertPlain(doc, "\n");
        }

        if (!bodyBlock.isEmpty()) {
            insertPlain(doc, bodyBlock);
        }
    }

    private void insertStartLine(javax.swing.text.StyledDocument doc, String line) {
        // Uniform single color for the whole line — request or response —
        // rather than singling out just the status code in a different
        // color, which looked inconsistent line-to-line (obviously
        // two-toned for a 2xx response, barely distinguishable for a 5xx
        // one, since red and this line's base color are both warm tones).
        insertStyled(doc, line, styleOf(START_LINE_COLOR, true));
    }

    private static javax.swing.text.AttributeSet styleOf(Color color, boolean bold) {
        javax.swing.text.SimpleAttributeSet attrs = new javax.swing.text.SimpleAttributeSet();
        javax.swing.text.StyleConstants.setForeground(attrs, color);
        javax.swing.text.StyleConstants.setBold(attrs, bold);
        return attrs;
    }

    // Explicit "plain" style, used everywhere we'd otherwise pass null.
    // StyledDocument.insertString(pos, text, null) does NOT mean "no
    // styling" — it inherits whatever attributes are active on the
    // character immediately before the insertion point. That's exactly
    // what was causing "plain" text to randomly pick up blue (or whatever
    // color happened to precede it): a JSON key, a header name, etc. Every
    // insertion below now always passes an explicit AttributeSet, so
    // nothing is ever left to ambient/inherited state.
    private static final javax.swing.text.AttributeSet PLAIN_ATTRS = styleOf(Color.BLACK, false);

    private void insertPlain(javax.swing.text.StyledDocument doc, String text) {
        insertStyled(doc, text, PLAIN_ATTRS);
    }

    /**
     * Inserts `text` with the given style, wrapping it against the
     * running viewWrapColumn rather than trusting Swing's own line
     * breaking. Real '\n' characters already in `text` (header-line
     * separators, pretty-printed JSON) are preserved as-is and reset the
     * column; anywhere else, a break is forced once VIEW_WRAP_WIDTH would
     * be exceeded — preferring the last space in the current chunk (so
     * normal prose wraps at a word boundary) but falling back to a hard
     * character break if no such space exists close enough (so a single
     * long unbroken run — a cookie value, a minified JSON blob — still
     * wraps instead of silently overflowing or getting clipped).
     */
    private void insertStyled(javax.swing.text.StyledDocument doc, String text, javax.swing.text.AttributeSet attrs) {
        int i = 0;
        while (i < text.length()) {
            int nl = text.indexOf('\n', i);
            String segment = (nl == -1) ? text.substring(i) : text.substring(i, nl);

            int pos = 0;
            while (pos < segment.length()) {
                int roomLeft = VIEW_WRAP_WIDTH - viewWrapColumn;
                if (roomLeft <= 0) {
                    insertRaw(doc, "\n", PLAIN_ATTRS);
                    viewWrapColumn = 0;
                    roomLeft = VIEW_WRAP_WIDTH;
                }
                int take = Math.min(roomLeft, segment.length() - pos);
                int breakAt = take;
                if (pos + take < segment.length()) {
                    int lastSpace = segment.lastIndexOf(' ', pos + take - 1);
                    if (lastSpace > pos) breakAt = lastSpace - pos + 1; // keep the space with the line it ends
                }
                String piece = segment.substring(pos, pos + breakAt);
                insertRaw(doc, piece, attrs);
                viewWrapColumn += piece.length();
                pos += breakAt;
                if (pos < segment.length()) {
                    insertRaw(doc, "\n", PLAIN_ATTRS);
                    viewWrapColumn = 0;
                }
            }

            if (nl != -1) {
                insertRaw(doc, "\n", PLAIN_ATTRS);
                viewWrapColumn = 0;
                i = nl + 1;
            } else {
                i = text.length();
            }
        }
    }

    private void insertRaw(javax.swing.text.StyledDocument doc, String text, javax.swing.text.AttributeSet attrs) {
        try {
            doc.insertString(doc.getLength(), text, attrs);
        } catch (javax.swing.text.BadLocationException ignored) {
            // Can't happen — doc.getLength() is always a valid insertion point.
        }
    }

    private volatile Map<Validator, ValidationResult> lastResults = null;
    private volatile HttpRequest lastRequest = null;
    private volatile HttpResponse lastResponse = null;

    private void runValidation() {
        ProxyHttpRequestResponse item = selectedItem();
        if (item == null) {
            JOptionPane.showMessageDialog(root, "Select a request from the table first.");
            return;
        }

        final HttpRequest requestToSend = item.finalRequest();

        // Burp does not allow extensions to make blocking HTTP calls on the
        // Swing Event Dispatch Thread. SwingWorker runs doInBackground() on
        // a worker thread and hands the result back to done(), which Swing
        // guarantees runs on the EDT.
        setRunControlsEnabled(false);
        resultsTableModel.setRowCount(0);
        statusArea.setText("Replaying request...");

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            private String statusText;
            private List<Object[]> tableRows;
            private Map<Validator, ValidationResult> results;
            private HttpRequest sentRequest;
            private HttpResponse response;
            private String errorText;

            @Override
            protected Void doInBackground() {
                try {
                    response = api.http().sendRequest(requestToSend).response();
                } catch (Exception ex) {
                    errorText = "Failed to replay request: " + ex.getMessage();
                    return null;
                }

                if (response == null) {
                    errorText = "No response received on replay (target unreachable or request malformed).";
                    return null;
                }

                sentRequest = requestToSend;
                results = new java.util.LinkedHashMap<>();
                tableRows = new ArrayList<>();

                for (Map.Entry<Validator, JCheckBox> entry : validatorCheckboxes.entrySet()) {
                    if (!entry.getValue().isSelected()) continue;
                    Validator v = entry.getKey();
                    ValidationResult r;
                    try {
                        // CorsValidator sends its own probe requests (arbitrary
                        // Origin + a null-Origin probe) rather than being
                        // evaluated against the plain baseline replay above.
                        r = (v instanceof CorsValidator cv)
                                ? cv.validateWithProbes(requestToSend)
                                : v.validate(requestToSend, response);
                    } catch (Exception ex) {
                        r = ValidationResult.inconclusive("Validator threw an exception: " + ex.getMessage());
                    }
                    results.put(v, r);
                    tableRows.add(new Object[]{r.shortStatusLabel(), v.name(), r.detail()});
                }

                statusText = "Replayed: " + requestToSend.method() + " " + requestToSend.url() + "\n"
                        + "Status  : " + response.statusCode()
                        + (tableRows.isEmpty() ? "\n\nNo findings selected — tick at least one checkbox above, "
                        + "or use 'Select All'." : "");
                return null;
            }

            @Override
            protected void done() {
                setRunControlsEnabled(true);
                if (errorText != null) {
                    statusArea.setText(errorText);
                    return;
                }
                lastResults = results;
                lastRequest = sentRequest;
                lastResponse = response;
                statusArea.setText(statusText);
                resultsTableModel.setRowCount(0);
                for (Object[] row : tableRows) resultsTableModel.addRow(row);
                SwingUtilities.invokeLater(RetestTabUI.this::adjustResultsRowHeights);
            }
        };
        worker.execute();
    }

    private void setRunControlsEnabled(boolean enabled) {
        historyTable.setEnabled(enabled);
        for (JCheckBox cb : validatorCheckboxes.values()) cb.setEnabled(enabled);
        selectAllCheckbox.setEnabled(enabled);
    }

    /**
     * Writes everything from the last run in one go:
     *  - combined evidence "<host>_retest_result.html" (raw request/
     *    response + all verdicts as a STATUS/CONTROL NAME/REASON table —
     *    this is the single source of truth; no separate notes file).
     *    Re-running against the same host overwrites its previous
     *    evidence rather than piling up timestamped files.
     *  - one "<host>_p<port>_<code>.png" screenshot per finding, with the
     *    relevant response line(s) highlighted. For a finding that sent
     *    its own probe request (currently just CORS), the screenshot uses
     *    that probe's actual request/response rather than the generic
     *    baseline replay.
     * All honor the redact checkbox and land in the chosen output folder.
     */
    private void saveArtifacts() {
        if (lastResults == null || lastRequest == null || lastResponse == null) {
            JOptionPane.showMessageDialog(root, "Run a validation first.");
            return;
        }

        final boolean redact = redactCheckbox.isSelected();
        final Path targetDir = outputDir;
        final HttpRequest request = lastRequest;
        final HttpResponse response = lastResponse;
        final Map<Validator, ValidationResult> results = lastResults;
        final String runDate = DateTimeFormatter.ofPattern("dd-MM-yyyy").format(LocalDate.now());

        SwingUtilities.invokeLater(() -> {
            StringBuilder log = new StringBuilder();
            try {
                HtmlEvidenceWriter htmlWriter = new HtmlEvidenceWriter(targetDir);
                Path htmlFile = htmlWriter.write(request, response, results, redact, runDate);
                log.append("Saved evidence (html): ").append(htmlFile.toAbsolutePath()).append("\n");

                ScreenshotCapture capture = new ScreenshotCapture(targetDir);
                for (Map.Entry<Validator, ValidationResult> entry : results.entrySet()) {
                    ValidationResult result = entry.getValue();
                    // Use the finding's own probe request/response if it
                    // sent one (e.g. CORS's arbitrary-Origin probe),
                    // otherwise fall back to the baseline replay.
                    HttpRequest reqForShot = result.evidenceRequest() != null ? result.evidenceRequest() : request;
                    HttpResponse resForShot = result.evidenceResponse() != null ? result.evidenceResponse() : response;
                    Path png = capture.capturePerFinding(reqForShot, resForShot, entry.getKey(), result, redact);
                    log.append("Saved screenshot: ").append(png.toAbsolutePath()).append("\n");
                }
            } catch (Exception ex) {
                log.append("Failed to save artifacts: ").append(ex.getMessage()).append("\n");
            }
            statusArea.append("\n\n" + log);
        });
    }
}
