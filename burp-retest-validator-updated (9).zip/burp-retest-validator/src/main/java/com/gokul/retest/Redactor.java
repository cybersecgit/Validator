package com.gokul.retest;

import java.util.Set;

/**
 * Redacts sensitive header VALUES from raw HTTP request/response text,
 * keeping the header name visible so evidence still shows what was sent,
 * just not the secret.
 *
 * Scope/limitation: this only redacts header lines. It does not inspect
 * request/response BODIES, so a session token embedded in a JSON body
 * (e.g. {"access_token": "..."}) will NOT be redacted. If your findings
 * commonly carry tokens in the body, extend SENSITIVE_HEADERS handling
 * or add a body-pattern redaction pass — flagging this here rather than
 * silently under-redacting.
 */
public class Redactor {

    private static final Set<String> SENSITIVE_HEADERS = Set.of(
            "cookie",
            "set-cookie",
            "authorization",
            "proxy-authorization",
            "x-api-key",
            "x-auth-token",
            "x-csrf-token"
    );

    /** Redacts in place, line by line, over a raw HTTP message (request or response text). */
    public static String redact(String rawHttpMessage) {
        String[] lines = rawHttpMessage.split("\n", -1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            int colon = line.indexOf(':');
            boolean redacted = false;
            if (colon > 0) {
                String headerName = line.substring(0, colon).trim().toLowerCase();
                if (SENSITIVE_HEADERS.contains(headerName)) {
                    sb.append(line, 0, colon + 1).append(" [REDACTED]");
                    redacted = true;
                }
            }
            if (!redacted) sb.append(line);
            if (i < lines.length - 1) sb.append("\n");
        }
        return sb.toString();
    }
}
