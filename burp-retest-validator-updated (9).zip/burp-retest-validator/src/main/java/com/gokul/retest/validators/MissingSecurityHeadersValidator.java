package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.HeaderUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Combined check for the "Missing HTTP Security Headers" finding
 * (X-Content-Type-Options, X-Frame-Options, Strict-Transport-Security,
 * Content-Security-Policy all reported together as one finding, so this
 * validates them together too — separate from the standalone HSTS /
 * Clickjacking validators above, which report those as their own
 * finding categories).
 *
 * Recommended values checked:
 *   - X-Content-Type-Options: nosniff
 *   - X-Frame-Options: DENY or SAMEORIGIN
 *   - Strict-Transport-Security: max-age >= 31536000 with includeSubDomains
 *   - Content-Security-Policy: has a default-src directive that includes 'self'
 *     (additional directives/sources alongside it are fine)
 */
public class MissingSecurityHeadersValidator implements Validator {

    private static final long REQUIRED_MAX_AGE_SECONDS = 31536000;

    @Override
    public String name() { return "Missing HTTP Security Headers"; }

    @Override
    public String category() { return "Security Misconfiguration — Missing Headers"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        List<HttpHeader> headers = response.headers();

        for (String headerName : new String[]{
                "X-Content-Type-Options", "X-Frame-Options", "Strict-Transport-Security", "Content-Security-Policy"}) {
            Optional<List<String>> dup = HeaderUtils.duplicateWithDifferentValues(headers, headerName);
            if (dup.isPresent()) {
                return ValidationResult.fail(
                        "Duplicate " + headerName + " headers with different values: " + String.join("\n", dup.get()),
                        dup.get().toArray(new String[0]));
            }
        }

        List<String> subResults = new ArrayList<>();
        List<String> highlights = new ArrayList<>();
        boolean anyFail = false;

        // X-Content-Type-Options
        Optional<HttpHeader> xcto = HeaderUtils.findFirst(headers, "X-Content-Type-Options");
        if (xcto.isEmpty()) {
            subResults.add("X-Content-Type-Options: MISSING");
            anyFail = true;
        } else {
            highlights.add(HeaderUtils.line(xcto.get()));
            if (xcto.get().value().trim().equalsIgnoreCase("nosniff")) {
                subResults.add("X-Content-Type-Options: OK (nosniff)");
            } else {
                subResults.add("X-Content-Type-Options: WRONG VALUE (" + xcto.get().value() + ", expected nosniff)");
                anyFail = true;
            }
        }

        // X-Frame-Options
        Optional<HttpHeader> xfo = HeaderUtils.findFirst(headers, "X-Frame-Options");
        if (xfo.isEmpty()) {
            subResults.add("X-Frame-Options: MISSING");
            anyFail = true;
        } else {
            highlights.add(HeaderUtils.line(xfo.get()));
            String v = xfo.get().value().trim().toUpperCase(Locale.ROOT);
            if (v.equals("DENY") || v.equals("SAMEORIGIN")) {
                subResults.add("X-Frame-Options: OK (" + v + ")");
            } else {
                subResults.add("X-Frame-Options: WRONG VALUE (" + xfo.get().value() + ", expected DENY or SAMEORIGIN)");
                anyFail = true;
            }
        }

        // Strict-Transport-Security
        if (!request.httpService().secure()) {
            subResults.add("Strict-Transport-Security: N/A (not HTTPS)");
        } else {
            Optional<HttpHeader> hsts = HeaderUtils.findFirst(headers, "Strict-Transport-Security");
            if (hsts.isEmpty()) {
                subResults.add("Strict-Transport-Security: MISSING");
                anyFail = true;
            } else {
                highlights.add(HeaderUtils.line(hsts.get()));
                Long maxAge = extractMaxAge(hsts.get().value());
                boolean includeSub = hasDirective(hsts.get().value(), "includeSubDomains");
                if (maxAge != null && maxAge >= REQUIRED_MAX_AGE_SECONDS && includeSub) {
                    subResults.add("Strict-Transport-Security: OK (" + hsts.get().value() + ")");
                } else {
                    subResults.add("Strict-Transport-Security: WEAK (" + hsts.get().value()
                            + ", expected max-age >= 31536000 and includeSubDomains)");
                    anyFail = true;
                }
            }
        }

        // Content-Security-Policy
        Optional<HttpHeader> csp = HeaderUtils.findFirst(headers, "Content-Security-Policy");
        if (csp.isEmpty()) {
            subResults.add("Content-Security-Policy: MISSING");
            anyFail = true;
        } else {
            highlights.add(HeaderUtils.line(csp.get()));
            if (hasDefaultSrcSelf(csp.get().value())) {
                subResults.add("Content-Security-Policy: OK (default-src includes 'self')");
            } else {
                // Deliberately doesn't embed the raw CSP value here — it can
                // be very long, and it's already highlighted in the response
                // pane via `highlights` above.
                subResults.add("Content-Security-Policy: WEAK (expected a default-src directive that includes 'self')");
                anyFail = true;
            }
        }

        String detail = String.join("\n", subResults);
        String[] highlightArr = highlights.toArray(new String[0]);
        return anyFail ? ValidationResult.fail(detail, highlightArr) : ValidationResult.pass(detail, highlightArr);
    }

    private Long extractMaxAge(String headerValue) {
        for (String part : headerValue.split(";")) {
            part = part.trim();
            if (part.toLowerCase(Locale.ROOT).startsWith("max-age=")) {
                try {
                    return Long.parseLong(part.substring("max-age=".length()).trim());
                } catch (NumberFormatException e) {
                    return null;
                }
            }
        }
        return null;
    }

    private boolean hasDirective(String headerValue, String directive) {
        for (String part : headerValue.split(";")) {
            if (part.trim().equalsIgnoreCase(directive)) return true;
        }
        return false;
    }

    private boolean hasDefaultSrcSelf(String cspValue) {
        for (String directive : cspValue.split(";")) {
            String trimmed = directive.trim();
            if (trimmed.toLowerCase(Locale.ROOT).startsWith("default-src")) {
                return trimmed.toLowerCase(Locale.ROOT).contains("'self'");
            }
        }
        return false;
    }
}
