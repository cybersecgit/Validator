package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.HeaderUtils;

import java.util.List;
import java.util.Optional;

public class HstsValidator implements Validator {

    // Recommended baseline: max-age of one year, applied to subdomains too.
    private static final long REQUIRED_MAX_AGE_SECONDS = 31536000; // 1 year

    @Override
    public String name() { return "Missing/Weak HSTS"; }

    @Override
    public String category() { return "Security Misconfiguration — Transport"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        if (!request.httpService().secure()) {
            return ValidationResult.inconclusive("Request is not HTTPS; HSTS is not applicable.");
        }

        List<HttpHeader> headers = response.headers();

        // Duplicate-header check applies before anything else: two HSTS
        // headers with different values is itself an unreliable/failed fix.
        Optional<List<String>> dup = HeaderUtils.duplicateWithDifferentValues(headers, "Strict-Transport-Security");
        if (dup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate Strict-Transport-Security headers with different values — ambiguous/unreliable fix: "
                            + String.join("\n", dup.get()),
                    dup.get().toArray(new String[0]));
        }

        Optional<HttpHeader> hsts = HeaderUtils.findFirst(headers, "Strict-Transport-Security");

        if (hsts.isEmpty()) {
            // Nothing to highlight — the header simply isn't there.
            return ValidationResult.fail("Strict-Transport-Security header is absent.");
        }

        String headerLine = HeaderUtils.line(hsts.get());
        String value = hsts.get().value();

        Long maxAge = extractMaxAge(value);
        boolean includesSubDomains = hasDirective(value, "includeSubDomains");

        // Required: max-age >= 31536000 AND includeSubDomains present.
        // (The recommended fix value is "max-age=31536000; includeSubDomains" —
        // both parts are required together, not either/or.)
        if (maxAge == null) {
            return ValidationResult.fail("HSTS header present but no max-age directive found: " + value, headerLine);
        }
        if (maxAge < REQUIRED_MAX_AGE_SECONDS && !includesSubDomains) {
            return ValidationResult.fail("HSTS max-age is below 31536000 (" + maxAge
                    + "s) AND includeSubDomains is missing: " + value, headerLine);
        }
        if (maxAge < REQUIRED_MAX_AGE_SECONDS) {
            return ValidationResult.fail("HSTS max-age is below 31536000 (" + maxAge + "s): " + value, headerLine);
        }
        if (!includesSubDomains) {
            return ValidationResult.fail("HSTS max-age is adequate but includeSubDomains is missing: " + value, headerLine);
        }

        return ValidationResult.pass("HSTS present with max-age >= 31536000 and includeSubDomains: " + value, headerLine);
    }

    private Long extractMaxAge(String headerValue) {
        for (String part : headerValue.split(";")) {
            part = part.trim();
            if (part.toLowerCase().startsWith("max-age=")) {
                try {
                    return Long.parseLong(part.substring("max-age=".length()).trim());
                } catch (NumberFormatException e) {
                    return null;
                }
            }
        }
        return null;
    }

    private boolean hasDirective(String headerValue, String directive) {
        for (String part : headerValue.split(";")) {
            if (part.trim().equalsIgnoreCase(directive)) return true;
        }
        return false;
    }
}
