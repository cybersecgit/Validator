package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.params.HttpParameterType;
import burp.api.montoya.http.message.params.ParsedHttpParameter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Flags sensitive-looking data sent in a GET request's URL/query string
 * (params are logged in server/proxy access logs, browser history, and
 * Referer headers to third parties — an issue even over HTTPS).
 *
 * NOTE on Montoya API surface: this uses request.parameters() filtered
 * to HttpParameterType.URL. Per this project's existing caveat about
 * exact Montoya method names drifting between releases (see README),
 * double-check this against the Montoya version bundled with your Burp
 * install (Extensions -> APIs tab) if it doesn't compile as-is.
 */
public class SensitiveGetParamValidator implements Validator {

    private static final Pattern SENSITIVE_PARAM_NAME = Pattern.compile(
            "(?i)^(password|passwd|pwd|pass|secret|token|access_?token|refresh_?token|"
                    + "api[_-]?key|apikey|auth|authorization|session(id)?|sid|ssn|social_?security|"
                    + "credit_?card|card_?number|cvv|cvv2|pin|private_?key|client_?secret|otp)$");

    @Override
    public String name() { return "Sensitive Data in GET Request"; }

    @Override
    public String category() { return "Information Disclosure — Sensitive Data in URL"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        if (!"GET".equalsIgnoreCase(request.method())) {
            return ValidationResult.inconclusive("Not a GET request; this check only applies to GET requests.");
        }

        List<ParsedHttpParameter> urlParams;
        try {
            urlParams = request.parameters(HttpParameterType.URL);
        } catch (Exception ex) {
            return ValidationResult.inconclusive("Could not parse URL parameters: " + ex.getMessage());
        }

        if (urlParams == null || urlParams.isEmpty()) {
            return ValidationResult.pass("No query-string parameters present on this GET request.");
        }

        List<String> flagged = new ArrayList<>();
        for (ParsedHttpParameter p : urlParams) {
            if (SENSITIVE_PARAM_NAME.matcher(p.name().trim()).matches()) {
                String preview = p.value() != null && p.value().length() > 6
                        ? p.value().substring(0, 6) + "..." : "(short/empty value)";
                flagged.add(p.name() + "=" + preview);
            }
        }

        if (flagged.isEmpty()) {
            return ValidationResult.pass("GET query string present but no sensitive-looking parameter names found: "
                    + String.join(", ", urlParams.stream().map(ParsedHttpParameter::name).toList()));
        }

        return ValidationResult.fail(
                "GET request query string carries sensitive-looking parameter(s): " + String.join(", ", flagged)
                        + " — these end up in server/proxy access logs, browser history, and any Referer header sent "
                        + "to third-party resources. Recommend moving to the request body (and still not logging them).",
                request.url());
    }
}
