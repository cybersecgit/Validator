package com.gokul.retest;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import com.gokul.retest.validators.Validator;
import com.gokul.retest.validators.ValidationResult;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

/**
 * Writes the combined evidence artifact for a retest run: the raw
 * request/response plus every validator's verdict, rendered as a real,
 * colour-coded STATUS / CONTROL NAME / REASON &lt;table&gt; in a single
 * self-contained HTML page. This is the only evidence artifact this
 * extension writes (no plain-text sibling) — everything a report needs
 * lives in this one file, alongside the per-finding screenshots.
 *
 * Filename is "<host>_retest_result.html" — a fixed name per host, not
 * per run, so re-running Validate/Save Artifacts against the same host
 * overwrites its previous evidence rather than piling up timestamped
 * files.
 */
public class HtmlEvidenceWriter {

    private final Path outputDir;

    public HtmlEvidenceWriter(Path outputDir) throws IOException {
        this.outputDir = outputDir;
        Files.createDirectories(outputDir);
    }

    /**
     * @param runDate display-only date string (e.g. "02-09-2026"), not used in the filename.
     */
    public Path write(HttpRequest request,
                       HttpResponse response,
                       Map<Validator, ValidationResult> results,
                       boolean redact,
                       String runDate) throws IOException {

        String safeHost = safeHost(request);
        Path file = outputDir.resolve(safeHost + "_retest_result.html");

        String rawRequest = redact ? Redactor.redact(request.toString()) : request.toString();
        String rawResponse = redact ? Redactor.redact(response.toString()) : response.toString();

        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\">\n");
        sb.append("<title>Retest Evidence - ").append(escape(safeHost)).append(" ").append(escape(runDate)).append("</title>\n");
        sb.append("<style>\n");
        sb.append("body{font-family:Arial,Helvetica,sans-serif;margin:24px;color:#222;}\n");
        sb.append("h1{font-size:19px;} h2{font-size:15px;margin-top:28px;}\n");
        sb.append("table{border-collapse:collapse;width:100%;table-layout:fixed;}\n");
        sb.append("th,td{border:1px solid #ccc;padding:6px 8px;text-align:left;vertical-align:top;");
        sb.append("word-wrap:break-word;font-size:13px;}\n");
        sb.append("th{background:#eee;}\n");
        // Generic (not td-only) so these widths also apply to the header
        // row's <th> cells — table-layout:fixed determines column widths
        // from the first row, so the header cells need the class too.
        sb.append(".status{width:8%;font-weight:bold;text-align:left;}\n");
        sb.append(".name{width:46%;}\n");
        sb.append(".reason{width:46%;}\n");
        sb.append("td.reason{white-space:pre-line;}\n"); // keeps our embedded '\n' points on their own line
        sb.append(".status-PASS{background:#dff5df;} .status-FAIL{background:#f9d6d6;} .status-REVIEW{background:#fdf1cf;}\n");
        sb.append("pre{background:#f7f7f7;border:1px solid #ddd;padding:10px;white-space:pre-wrap;");
        sb.append("word-wrap:break-word;font-size:12px;overflow-x:auto;}\n");
        sb.append(".cat{font-weight:normal;font-size:11px;color:#666;display:block;margin-top:2px;}\n");
        sb.append("</style></head><body>\n");

        sb.append("<h1>Retest Evidence</h1>\n<p>");
        sb.append("<b>Date:</b> ").append(escape(runDate)).append("<br>\n");
        sb.append("<b>URL:</b> ").append(escape(request.url())).append("<br>\n");
        sb.append("<b>Redacted:</b> ").append(redact).append("</p>\n");

        sb.append("<h2>Validator Results</h2>\n");
        sb.append("<table>\n<tr><th class=\"status\">STATUS</th><th class=\"name\">CONTROL NAME</th><th class=\"reason\">REASON</th></tr>\n");
        for (Map.Entry<Validator, ValidationResult> entry : results.entrySet()) {
            Validator v = entry.getKey();
            ValidationResult r = entry.getValue();
            String label = r.shortStatusLabel();
            sb.append("<tr class=\"status-").append(label).append("\">\n");
            sb.append("  <td class=\"status\">").append(label).append("</td>\n");
            sb.append("  <td class=\"name\">").append(escape(v.name()))
                    .append("<span class=\"cat\">").append(escape(v.category())).append("</span></td>\n");
            sb.append("  <td class=\"reason\">").append(escape(r.detail())).append("</td>\n");
            sb.append("</tr>\n");
        }
        sb.append("</table>\n");

        sb.append("<h2>Raw Request</h2>\n<pre>").append(escape(rawRequest)).append("</pre>\n");
        sb.append("<h2>Raw Response</h2>\n<pre>").append(escape(rawResponse)).append("</pre>\n");

        sb.append("</body></html>\n");

        Files.write(file, sb.toString().getBytes(StandardCharsets.UTF_8));
        return file;
    }

    private String safeHost(HttpRequest request) {
        return request.httpService().host().replaceAll("[^a-zA-Z0-9.-]", "_");
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
