package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.HeaderUtils;

import java.util.List;
import java.util.Optional;

public class ClickjackingValidator implements Validator {

    @Override
    public String name() { return "Missing Clickjacking Protection (X-Frame-Options / CSP frame-ancestors)"; }

    @Override
    public String category() { return "Security Misconfiguration — Clickjacking"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        List<HttpHeader> headers = response.headers();

        Optional<List<String>> xfoDup = HeaderUtils.duplicateWithDifferentValues(headers, "X-Frame-Options");
        if (xfoDup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate X-Frame-Options headers with different values: " + String.join("\n", xfoDup.get()),
                    xfoDup.get().toArray(new String[0]));
        }
        Optional<List<String>> cspDup = HeaderUtils.duplicateWithDifferentValues(headers, "Content-Security-Policy");
        if (cspDup.isPresent()) {
            return ValidationResult.fail(
                    "Duplicate Content-Security-Policy headers with different values: " + String.join("\n", cspDup.get()),
                    cspDup.get().toArray(new String[0]));
        }

        Optional<HttpHeader> xfo = HeaderUtils.findFirst(headers, "X-Frame-Options");
        Optional<HttpHeader> csp = HeaderUtils.findFirst(headers, "Content-Security-Policy");

        boolean cspHasFrameAncestors = csp.isPresent()
                && csp.get().value().toLowerCase().contains("frame-ancestors");

        if (xfo.isPresent()) {
            String headerLine = xfo.get().name() + ": " + xfo.get().value();
            String val = xfo.get().value().trim().toUpperCase();
            if (val.equals("DENY") || val.equals("SAMEORIGIN") || val.startsWith("ALLOW-FROM")) {
                return ValidationResult.pass("X-Frame-Options: " + xfo.get().value(), headerLine);
            }
            return ValidationResult.fail("X-Frame-Options present but value looks non-standard: "
                    + xfo.get().value(), headerLine);
        }

        if (cspHasFrameAncestors) {
            String headerLine = csp.get().name() + ": " + csp.get().value();
            return ValidationResult.pass("CSP frame-ancestors directive present: " + csp.get().value(), headerLine);
        }

        // Neither present — nothing to highlight, the absence IS the finding.
        return ValidationResult.fail("Neither X-Frame-Options nor CSP frame-ancestors is set — page is frameable.");
    }
}
