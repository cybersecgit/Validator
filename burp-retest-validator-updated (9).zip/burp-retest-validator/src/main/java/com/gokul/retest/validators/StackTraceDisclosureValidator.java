package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Bonus validator (see README "Good next candidates"): flags verbose
 * error/stack-trace disclosure in the response body — a common finding
 * on retest where the underlying bug was fixed but the framework's
 * debug/error page was never turned off in the target environment.
 *
 * Uses response.bodyToString() per the general Montoya API shape used
 * elsewhere in this project — verify against your bundled Montoya
 * version if it doesn't compile as-is (see README caveats).
 */
public class StackTraceDisclosureValidator implements Validator {

    private static final List<Pattern> PATTERNS = List.of(
            Pattern.compile("Exception in thread"),
            Pattern.compile("(?i)Traceback \\(most recent call last\\)"),
            Pattern.compile("at [\\w.$]+\\([\\w.]+\\.java:\\d+\\)"),                  // Java stack frame
            Pattern.compile("(?i)System\\.NullReferenceException|System\\.Web\\.HttpException"),
            Pattern.compile("(?i)Fatal error:.*on line \\d+"),                         // PHP
            Pattern.compile("(?i)Warning: (mysql_|pg_|mysqli_)"),
            Pattern.compile("(?i)ORA-\\d{5}"),                                          // Oracle
            Pattern.compile("(?i)Microsoft OLE DB Provider for (SQL Server|ODBC Drivers)"),
            Pattern.compile("(?i)django\\.core\\.exceptions|Django Debug Toolbar"),
            Pattern.compile("(?i)WhitelabelErrorPage|org\\.springframework\\..*Exception")
    );

    @Override
    public String name() { return "Verbose Error / Stack Trace Disclosure"; }

    @Override
    public String category() { return "Information Disclosure"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        String body;
        try {
            body = response.bodyToString();
        } catch (Exception ex) {
            return ValidationResult.inconclusive("Could not read response body: " + ex.getMessage());
        }
        if (body == null || body.isBlank()) {
            return ValidationResult.pass("Response body is empty; nothing to check.");
        }

        List<String> matches = new ArrayList<>();
        for (Pattern p : PATTERNS) {
            var m = p.matcher(body);
            if (m.find()) {
                int start = Math.max(0, m.start() - 20);
                int end = Math.min(body.length(), m.end() + 40);
                matches.add(body.substring(start, end).replaceAll("\\s+", " ").trim());
            }
        }

        if (matches.isEmpty()) {
            return ValidationResult.pass("No known stack-trace/verbose-error patterns found in the response body.");
        }
        return ValidationResult.fail(
                "Response body appears to contain a stack trace or verbose framework error: "
                        + String.join("\n", matches),
                matches.toArray(new String[0]));
    }
}
