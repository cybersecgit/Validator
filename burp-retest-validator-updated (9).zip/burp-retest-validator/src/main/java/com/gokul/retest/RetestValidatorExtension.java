package com.gokul.retest;

import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;

public class RetestValidatorExtension implements BurpExtension {

    @Override
    public void initialize(MontoyaApi api) {
        api.extension().setName("Retest Validator");

        RetestTabUI tab = new RetestTabUI(api);
        api.userInterface().registerSuiteTab("Retest Validator", tab.getComponent());

        api.logging().logToOutput("Retest Validator extension loaded. "
                + "Browse the target in Burp's browser, then use the "
                + "'Retest Validator' tab to pick a request and run checks.");
    }
}
