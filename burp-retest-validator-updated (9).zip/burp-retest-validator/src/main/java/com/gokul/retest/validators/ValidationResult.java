package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ValidationResult {

    public enum Status { PASS, FAIL, INCONCLUSIVE }

    private final Status status;
    private final String detail;
    private final List<String> highlightTexts; // exact substrings to highlight in the screenshot, if any

    // Optional: the specific request/response pair that actually produced
    // this verdict, when it differs from the baseline replay (e.g.
    // CorsValidator sends its own arbitrary-Origin / null-Origin probes).
    // Null means "use the baseline request/response" — see withEvidence().
    private final HttpRequest evidenceRequest;
    private final HttpResponse evidenceResponse;

    private ValidationResult(Status status, String detail, List<String> highlightTexts,
                              HttpRequest evidenceRequest, HttpResponse evidenceResponse) {
        this.status = status;
        this.detail = detail;
        this.highlightTexts = highlightTexts;
        this.evidenceRequest = evidenceRequest;
        this.evidenceResponse = evidenceResponse;
    }

    private static List<String> clean(String... texts) {
        if (texts == null) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        for (String t : texts) {
            if (t != null && !t.isBlank()) out.add(t);
        }
        return out;
    }

    public static ValidationResult pass(String detail, String... highlightTexts) {
        return new ValidationResult(Status.PASS, detail, clean(highlightTexts), null, null);
    }

    public static ValidationResult fail(String detail, String... highlightTexts) {
        return new ValidationResult(Status.FAIL, detail, clean(highlightTexts), null, null);
    }

    public static ValidationResult inconclusive(String detail, String... highlightTexts) {
        return new ValidationResult(Status.INCONCLUSIVE, detail, clean(highlightTexts), null, null);
    }

    public Status status() { return status; }
    public String detail() { return detail; }

    /**
     * Exact substrings (usually header lines, e.g. "Server: Apache/2.4.41")
     * to highlight in the response panel screenshot. Empty if there's
     * nothing to highlight (e.g. the header is simply absent).
     */
    public List<String> highlightTexts() { return highlightTexts; }

    /** "Still vulnerable" == the original weak state is still present. */
    public boolean stillVulnerable() { return status == Status.FAIL; }

    /**
     * Returns a copy of this result carrying the specific request/response
     * pair that produced it. Use this when a validator sends its own probe
     * request(s) rather than being evaluated against the plain baseline
     * replay (e.g. CorsValidator's arbitrary-Origin probe) — the saved
     * screenshot for that finding will then show the actual probe request
     * (with the tested Origin header, etc.) instead of the generic
     * baseline request.
     */
    public ValidationResult withEvidence(HttpRequest request, HttpResponse response) {
        return new ValidationResult(status, detail, highlightTexts, request, response);
    }

    /** Null unless withEvidence() was used — falls back to the baseline request/response. */
    public HttpRequest evidenceRequest() { return evidenceRequest; }

    /** Null unless withEvidence() was used — falls back to the baseline request/response. */
    public HttpResponse evidenceResponse() { return evidenceResponse; }

    /**
     * Short status word for space-constrained displays: the screenshot
     * banner and the STATUS column of the results table.
     */
    public String shortStatusLabel() {
        return switch (status) {
            case PASS -> "PASS";
            case FAIL -> "FAIL";
            case INCONCLUSIVE -> "REVIEW";
        };
    }

    @Override
    public String toString() {
        return "[" + status + "] " + detail;
    }
}
