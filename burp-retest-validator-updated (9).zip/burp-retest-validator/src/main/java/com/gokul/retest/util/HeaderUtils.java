package com.gokul.retest.util;

import burp.api.montoya.http.message.HttpHeader;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Small shared helpers used by every header-based validator:
 *  - case-insensitive header lookup
 *  - duplicate-header-with-different-values detection
 *
 * Rationale for the duplicate check: a header repeated with two
 * different values is itself a config bug worth flagging on retest —
 * which value "wins" is server/proxy/CDN-dependent and not something a
 * pentester should have to guess about, so validators here treat it as
 * a FAIL rather than silently picking the first occurrence. A header
 * repeated with the *same* value twice is not flagged — that's usually
 * harmless (e.g. a header added by both an app and a reverse proxy).
 */
public final class HeaderUtils {

    private HeaderUtils() { }

    public static List<HttpHeader> findAll(List<HttpHeader> headers, String name) {
        return headers.stream()
                .filter(h -> h.name().equalsIgnoreCase(name))
                .collect(Collectors.toList());
    }

    public static Optional<HttpHeader> findFirst(List<HttpHeader> headers, String name) {
        return findAll(headers, name).stream().findFirst();
    }

    public static String line(HttpHeader h) {
        return h.name() + ": " + h.value();
    }

    /**
     * Checks for 2+ occurrences of {@code name} whose values differ.
     * Returns the offending header lines (for the FAIL detail/highlight)
     * if found, or empty if the header appears 0-1 times, or 2+ times
     * with identical values.
     */
    public static Optional<List<String>> duplicateWithDifferentValues(List<HttpHeader> headers, String name) {
        List<HttpHeader> matches = findAll(headers, name);
        if (matches.size() < 2) return Optional.empty();

        Set<String> distinctValues = new LinkedHashSet<>();
        for (HttpHeader h : matches) distinctValues.add(h.value());
        if (distinctValues.size() < 2) return Optional.empty();

        List<String> lines = new ArrayList<>();
        for (HttpHeader h : matches) lines.add(line(h));
        return Optional.of(lines);
    }
}
