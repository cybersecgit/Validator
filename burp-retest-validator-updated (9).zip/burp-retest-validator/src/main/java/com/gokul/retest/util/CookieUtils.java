package com.gokul.retest.util;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Heuristic cookie-name classification, shared by:
 *  - CookieFlagsValidator (skip WAF/CDN cookies when flagging missing
 *    Secure/HttpOnly, per retest team feedback: they don't want WAF
 *    session cookies cluttering the finding)
 *  - CorsValidator (treat presence of a non-WAF cookie on the request
 *    as "this endpoint uses cookie-based auth" for the CORS matrix)
 *
 * This is a heuristic, not a guarantee — new WAF/CDN vendors appear
 * over time. If you see a vendor cookie slipping through (or an app
 * cookie being wrongly excluded), extend the pattern list below.
 */
public final class CookieUtils {

    private CookieUtils() { }

    // Cookies set by WAFs/CDNs/load balancers rather than the application.
    // Not security-meaningful for "does this app use cookie auth" purposes.
    private static final List<Pattern> WAF_OR_INFRA_COOKIE_PATTERNS = List.of(
            Pattern.compile("^incap_ses.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^visid_incap.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^nlbi_.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^___utmvc.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^__cfduid$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^cf_clearance$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^cf_bm$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^ak_bmsc$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^bm_sz$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^bm_mi$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^_abck$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^awsalb.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^awsalbcors.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^ts[0-9a-f]{6,}$", Pattern.CASE_INSENSITIVE),      // F5 BIG-IP ASM (TSxxxxxxxx)
            Pattern.compile("^bigipserver.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^f5-.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^citrix_ns_id$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^ns_af.*", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^barra_counter_session$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^__cf_bm$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^x-waf.*", Pattern.CASE_INSENSITIVE)
    );

    public static boolean isLikelyWafOrInfraCookie(String cookieName) {
        if (cookieName == null) return false;
        String trimmed = cookieName.trim();
        for (Pattern p : WAF_OR_INFRA_COOKIE_PATTERNS) {
            if (p.matcher(trimmed).matches()) return true;
        }
        return false;
    }

    /**
     * True if the request's Cookie header carries at least one cookie
     * that isn't a WAF/infra cookie — used as a proxy for "this request
     * is authenticated via a session cookie".
     */
    public static boolean requestUsesCookieAuth(String cookieHeaderValue) {
        if (cookieHeaderValue == null || cookieHeaderValue.isBlank()) return false;
        for (String pair : cookieHeaderValue.split(";")) {
            String name = pair.trim();
            int eq = name.indexOf('=');
            if (eq > 0) name = name.substring(0, eq);
            name = name.trim();
            if (!name.isEmpty() && !isLikelyWafOrInfraCookie(name)) {
                return true;
            }
        }
        return false;
    }
}
