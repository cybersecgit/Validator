package com.gokul.retest.validators;

import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.http.message.HttpHeader;
import com.gokul.retest.util.CookieUtils;
import com.gokul.retest.util.HeaderUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Flags application-level cookies (Set-Cookie) missing the Secure and/or
 * HttpOnly flags. WAF/CDN/load-balancer cookies (Incapsula, Akamai,
 * Cloudflare, F5 BIG-IP, Citrix ADC/NetScaler, AWS ALB, etc.) are
 * excluded per team feedback — see CookieUtils for the exclusion list.
 */
public class CookieFlagsValidator implements Validator {

    @Override
    public String name() { return "Cookie Missing Secure/HttpOnly Flag"; }

    @Override
    public String category() { return "Security Misconfiguration — Session Cookies"; }

    @Override
    public ValidationResult validate(HttpRequest request, HttpResponse response) {
        List<HttpHeader> setCookieHeaders = HeaderUtils.findAll(response.headers(), "Set-Cookie");
        if (setCookieHeaders.isEmpty()) {
            return ValidationResult.inconclusive("No Set-Cookie headers on this response to evaluate.");
        }

        List<String> flaggedLines = new ArrayList<>();
        List<String> issues = new ArrayList<>();
        List<String> skippedWaf = new ArrayList<>();

        for (HttpHeader h : setCookieHeaders) {
            String value = h.value();
            String cookieName = value.contains("=") ? value.substring(0, value.indexOf('=')).trim() : value.trim();

            if (CookieUtils.isLikelyWafOrInfraCookie(cookieName)) {
                skippedWaf.add(cookieName);
                continue;
            }

            String lower = value.toLowerCase(Locale.ROOT);
            boolean hasSecure = hasAttribute(lower, "secure");
            boolean hasHttpOnly = hasAttribute(lower, "httponly");

            String line = HeaderUtils.line(h);
            List<String> missing = new ArrayList<>();
            if (!hasSecure) missing.add("Secure");
            if (!hasHttpOnly) missing.add("HttpOnly");

            if (!missing.isEmpty()) {
                flaggedLines.add(line);
                issues.add(cookieName + " missing " + String.join(" and ", missing));
            }
        }

        if (issues.isEmpty()) {
            String note = skippedWaf.isEmpty() ? "" : " (excluded WAF/infra cookies: " + String.join(", ", skippedWaf) + ")";
            return ValidationResult.pass("All application-level cookies set Secure and HttpOnly." + note);
        }

        return ValidationResult.fail(String.join("\n", issues), flaggedLines.toArray(new String[0]));
    }

    private boolean hasAttribute(String lowerCookieValue, String attribute) {
        for (String part : lowerCookieValue.split(";")) {
            if (part.trim().equals(attribute)) return true;
        }
        return false;
    }
}
