# Retest Validator — Burp Extension

## Changelog (round 3)

- Fixed a real CORS validation bug: when a probe with an arbitrary Origin
  got back an ACAO value that did NOT reflect it (i.e. a fixed/allowlisted
  origin — the actual secure behavior), the validator called that
  "review manually" instead of confirming the fix. It's a `PASS` now.
- CORS screenshots/evidence now also highlight the
  Access-Control-Allow-Credentials line wherever it's present, not just
  Access-Control-Allow-Origin.
- Removed the `.txt` evidence file entirely — only the `.html` evidence
  file is written now, and every place that mentioned ".txt" (button
  tooltips, the in-app "saved evidence" note, the screenshot's body-
  truncation message) has been updated to stop referencing it.
- Fixed unreadable dark-mode screenshots: every text component in a saved
  finding screenshot (banner title/reason, request/response panes, pane
  headers) now sets its own explicit black text color instead of
  inheriting Burp's look-and-feel default, which under a dark theme was a
  light/white color rendering almost invisibly on this tool's light
  pastel banner and yellow-highlight backgrounds.
- Findings panel is more compact: removed the double-line spacing around
  "Select All"/"Redact", and moved both into a single row below the
  checklist instead of each on its own separate line — frees up several
  rows of vertical space for the proxy history list above it.

## Changelog (round 2)

- Status label is `FAIL` again (not `WEAK`), everywhere — banner, results
  table, and `.txt`/`.html` evidence.
- Extension window results are now a real color-coded `JTable`: **green**
  for PASS, **red** for FAIL, **yellow** for REVIEW — matching the `.html`
  evidence's row colors, not just plain text.
- Screenshot banners show a one-line-to-a-few-lines general overview again
  (capped at ~480 chars) instead of just the bare status word — still
  never embeds an entire raw header value (e.g. full CSP policy).
- Fixed the CORS screenshot still not showing the tested `Origin` header:
  the probe now adds the header if the baseline request didn't have one
  (previously relied on an update-only header call that silently no-op'd
  when `Origin` was absent).
- Findings/buttons row are now center-aligned (previously buttons were
  left-aligned while checkboxes looked centered).
- Evidence files are now named `<host>_retest_result.txt`/`.html`, and
  screenshots `<host>_p<port>_<code>.png` — no more run ID/index in the
  filename, so re-running against the same host overwrites its previous
  artifacts. The evidence file itself shows a plain `Date: dd-MM-yyyy`
  instead of a full timestamp.
- Fixed screenshot response bodies with no real newlines (e.g. minified
  HTML) blowing past the 5-line cap — now also capped by character count.
- "Refresh" renamed back to **Refresh from Proxy History**.
- Doubled the vertical spacing around "Select All" and the redact
  checkbox so they read as separate from the findings list.
- Multi-point reasons (duplicate headers, combined missing-header check,
  etc.) now put each point on its own line instead of separating them
  with `|`.

## Changelog (round 1)

- Added a search box to filter the proxy history list.
- Removed the CORS "always probes with an arbitrary Origin" note label.
- CORS screenshots now show the actual arbitrary-Origin probe
  request/response (not the generic baseline replay), so the tested
  `Origin` header is visible as evidence.
- Screenshot response body truncated to 5 lines (was 40).
- Removed the Referrer-Policy validator/checkbox.
- CSP (and every other) screenshot banner now shows a short status word
  (`PASS`/`WEAK`/`REVIEW`) instead of the full reason text, so a
  misconfigured CSP no longer dumps its entire header value into the banner.
- Results (extension window + saved `.txt`) are now a word-wrapped
  `STATUS | CONTROL NAME | REASON` table instead of one clumsy line per
  finding. Both `.txt` and `.html` evidence are written on Save.
- Added a **View** button / double-click to inspect a proxy history
  row's raw request/response before validating — helps pick the right
  entry when several requests share a URL.
- Buttons renamed to **Validate** / **Save Artifacts**.
- Added a **Select All** checkbox; all finding checkboxes now default
  to unticked (only "Redact..." defaults on).


A Burp Suite extension that adds a **"Retest Validator"** tab. It reads
requests straight from Burp's own proxy history (no separate capture
needed — Burp's proxy already is the interceptor), lets you pick one,
tick which findings to re-check, replays it using whatever session is
currently live in Burp's browser, runs a set of pluggable validators
against the response, and saves evidence artifacts locally.

## What's implemented

- Suite tab UI: proxy history table (with a live search/filter box),
  validator checkboxes with a "Select All" toggle, a request/response
  viewer for the selected history row, and short **Validate** / **Save
  Artifacts** buttons.
- **Search proxy history** — a search box above the table filters rows
  (method/URL/status) live as you type, case-insensitively. Selecting a
  row and running Validate/Save works the same whether the list is
  filtered or not.
- **View selected request/response** — the **View** button (or a
  double-click on a row) opens a read-only side-by-side viewer of that
  row's raw request/response, so when several entries share a URL (e.g.
  repeated POSTs with different bodies) you can confirm you've picked
  the right one *before* replaying it.
- **Configurable output folder** — "Choose Folder..." picks where all
  artifacts are written (defaults to `~/retest-evidence`).
- Request replay via Burp's own HTTP client, off the Swing EDT via
  `SwingWorker` (Burp does not allow blocking HTTP calls on the UI thread).
- **Findings default to unticked** (only the "Redact sensitive header
  values" option is on by default) — tick individual findings, or use
  **Select All**, then **Validate**.
- Ten validators:
  - **HSTS** — missing/weak `Strict-Transport-Security`. Requires
    `max-age >= 31536000` **and** `includeSubDomains` together (both
    are required, not either/or) to pass.
  - **Clickjacking** — missing `X-Frame-Options` / CSP `frame-ancestors`.
  - **CORS Misconfiguration** — a single check (no separate probe
    checkbox anymore) that always replays with an arbitrary Origin to
    test for reflection, plus a second internal probe with a literal
    `null` Origin. Classifies the result against the same matrix
    testers use manually:
    - `ACAO reflects Origin + ACAC:true + cookie auth` → **FAIL**
    - `ACAO reflects Origin + ACAC:true + no cookie auth` → **PASS**
    - `ACAO reflects Origin + ACAC:true + ACA-Headers: Authorization` → **FAIL**
    - `ACAO: null + ACAC:true + cookie auth + no X-Frame-Options` → **FAIL**
    - `ACAO: *` → **PASS**
  - **Server/Tech Version Disclosure** — `Server`, `X-Powered-By`,
    `X-AspNet(-Mvc)-Version` headers leaking version strings.
  - **Obsolete X-XSS-Protection Header** — must be absent or `0`; any
    other value fails (the header is obsolete and its legacy
    `1; mode=block` behavior has its own XSS-adjacent history).
  - **CSP Misconfiguration** — a local, offline heuristic approximating
    the high-severity checks from csp-evaluator.withgoogle.com
    (`unsafe-inline`, `unsafe-eval`, wildcard/scheme-only sources,
    missing `object-src 'none'`, missing `base-uri`). **This is not a
    drop-in replacement for csp-evaluator** — it doesn't track known
    JSONP-bypass CDN paths and isn't as exhaustive. Treat a PASS as "no
    obvious high-severity issue found by this heuristic" and still
    spot-check meaningful policies manually.
  - **Missing HTTP Security Headers** — the combined finding some teams
    report separately from the individual HSTS/Clickjacking findings
    above: checks `X-Content-Type-Options: nosniff`,
    `X-Frame-Options: DENY|SAMEORIGIN`, HSTS (same rule as above), and
    `Content-Security-Policy` with a `default-src` that includes
    `'self'`, all together as one PASS/FAIL.
  - **Cookie Missing Secure/HttpOnly Flag** — flags application-level
    `Set-Cookie` headers missing `Secure` and/or `HttpOnly`. Known
    WAF/CDN/load-balancer cookies (Incapsula, Akamai, Cloudflare, F5
    BIG-IP, Citrix ADC, AWS ALB, etc. — see `CookieUtils`) are excluded
    from the check so the finding stays focused on
    application/session cookies (e.g. `JSESSIONID`).
  - **Sensitive Data in GET Request** — flags sensitive-looking query
    string parameter names (password, token, api_key, session id, SSN,
    card number, etc.) on GET requests, since those end up in access
    logs, browser history, and any `Referer` header sent to third
    parties.
  - **Verbose Error / Stack Trace Disclosure** *(bonus, not originally
    requested)* — scans the response body for common Java/.NET/PHP/SQL
    /Django/Spring stack-trace and debug-error signatures.
- **Duplicate-header detection is built into every header-based
  validator above.** If a checked header appears twice with different
  values, that validator returns FAIL immediately (ambiguous/unreliable
  config), regardless of what either value individually says. A header
  repeated with the *same* value both times is not flagged.
- **Redaction** — an on-by-default checkbox strips the VALUES of
  sensitive headers (`Cookie`, `Set-Cookie`, `Authorization`,
  `Proxy-Authorization`, `X-Api-Key`, `X-Auth-Token`, `X-Csrf-Token`)
  from every saved artifact, keeping the header name visible so it's
  still clear what was sent. See `Redactor.java`.
- **Results table** — both the extension window's results pane and the
  saved `.html` evidence present verdicts as a `STATUS | CONTROL NAME |
  REASON` table instead of one long line per finding. `STATUS` uses
  short labels — `PASS` / `FAIL` / `REVIEW`.
- **Save Artifacts** produces, per run, into the chosen folder:
  - `HOST_retest_result.html` — the raw request/response plus every
    verdict as a colour-coded table, in one self-contained HTML page
    (redacted if selected). This is the only evidence artifact written —
    everything a report needs lives in this one file. Filename is fixed
    per host (not per run), so re-running against the same host
    overwrites its previous evidence rather than piling up timestamped
    files.
  - `HOST_pPORT_CODE.png` — **one screenshot per finding**, side-by-side
    request/response, with the specific offending response header
    line(s) **highlighted in yellow** and a colored PASS/FAIL/REVIEW
    banner at the top (the banner's reason text is capped at a few
    hundred characters — it's a general overview, not the full raw
    detail, which stays in the `.html` table). Every text element in the
    screenshot has an explicit color set rather than inheriting Burp's
    look-and-feel, so it renders correctly whether Burp is in light or
    dark mode. Response/request **headers are always shown in full**;
    the **body is truncated to 5 lines** so the screenshot stays
    readable without zooming — the full body is still in the `.html`.
    For **CORS**, the screenshot uses the actual arbitrary-Origin (or
    null-Origin) probe request/response that produced the verdict — not
    the generic baseline replay — so the tested `Origin` header is
    visible in the request pane as evidence. `CODE` is a short
    per-finding code (e.g. `HSTS`, `CORS`, `XXSS`, `CSP`, `HDRS`,
    `COOKIE`, `GETPII`) rather than the full finding name, and the host
    portion of the filename is capped/hashed if long, so filenames stay
    short enough to survive being moved to a shared drive. If a header
    is simply absent (nothing to highlight), the response pane notes
    that instead.

## Adding a new finding type

1. Create a new class in `validators/` implementing `Validator`.
2. In `validate()`, pass the relevant response header line(s) as extra
   arguments to `ValidationResult.pass(...)` / `.fail(...)` — these
   become the highlighted text in that finding's screenshot. Pass none
   if there's nothing to point at (e.g. a header that's simply missing).
3. If the header you're checking should also fail on duplicates with
   differing values, call `HeaderUtils.duplicateWithDifferentValues(...)`
   first (see any existing validator for the pattern).
4. Add `new YourValidator()` to the `allValidators` list built in
   `RetestTabUI`'s constructor.
5. Optional: give it a short filename code in
   `ScreenshotCapture.SHORT_CODES` (falls back to an auto-derived one
   if you skip this).

Good next candidates: directory listing enabled, open redirect,
SameSite cookie attribute checks beyond what `CookieFlagsValidator`
already covers, cache-control on pages carrying sensitive data.

## Building

Requires Maven and a JDK (17+). This environment has no internet
access to Maven Central, so build on a machine that does (your
workstation, once you confirm Maven can reach Central, or your org's
internal mirror).

```bash
cd burp-retest-validator
mvn clean package
```

Produces `target/burp-retest-validator.jar`.

## Loading into Burp

1. Burp Professional → **Extensions** tab → **Installed** → **Add**.
2. Extension type: **Java**.
3. Extension file: `target/burp-retest-validator.jar`.
4. A **"Retest Validator"** tab appears in the main Burp window.

No admin rights needed — loading an extension is just pointing Burp
at a `.jar` file.

## Using it

1. Browse the target through Burp's embedded browser (log in normally —
   whatever session that establishes is what gets used on replay).
2. **Retest Validator** tab → optionally **Choose Folder...** for artifacts.
3. **Refresh** → optionally type in the search box to narrow the list →
   select the request for the original finding (use **View**, or
   double-click the row, first if you need to confirm you've got the
   right request among several with the same URL).
4. Tick which findings to validate (all start unticked — use
   **Select All** if you want everything), leaving **Redact sensitive
   header values** checked unless you specifically need raw tokens in
   the evidence.
5. **Validate** — verdicts appear on the right as a table. (If CORS is
   ticked, it sends its own extra probe requests automatically — no
   separate checkbox to remember.)
6. **Save Artifacts** — writes the `.html` evidence, plus one
   highlighted screenshot per finding, to the output folder.

## Known caveats / things to verify

- **Montoya API surface**: exact method names (`api.proxy().history()`,
  `api.http().sendRequest(...)`, `HttpRequest.withUpdatedHeader(...)`,
  `HttpRequest.parameters(HttpParameterType.URL)`,
  `HttpResponse.bodyToString()`, etc.) are written against the general
  shape of the current Montoya API but should be checked against the
  version bundled with your Burp Professional install (`Extensions` →
  `APIs` tab) — Montoya has evolved release to release. This build
  environment has no internet access to Maven Central, so none of this
  has been compiled against the real Montoya jar — please do a
  `mvn clean package` on a machine with internet/mirror access and fix
  up any renamed methods before relying on it.
- **CSP validator is a local heuristic**, not a call-out to
  csp-evaluator.withgoogle.com (deliberately — sending your target's
  CSP value to an external site isn't something this extension should
  do without being asked). See the CSP bullet above for scope.
- **CORS validator's null-Origin probe is best-effort.** If that second
  request fails for any reason, the extension still returns the
  classification from the primary arbitrary-Origin probe; it just won't
  have evaluated scenario (d).
- **"Cookie auth" detection is a heuristic**: it's "does this request's
  Cookie header carry at least one cookie that isn't recognized as a
  WAF/infra cookie" (see `CookieUtils`). It doesn't confirm that cookie
  is actually the one used for session auth vs. some other app cookie.
- **Redaction covers headers only, not bodies.** A session token or
  API key embedded in a JSON/form body (e.g. `{"access_token": "..."}`)
  will NOT be redacted by the current `Redactor`. If your findings
  commonly carry secrets in the body, extend `Redactor` with a body
  pattern pass before relying on this for anything you'd share outside
  the team.
- **Off-screen screenshot rendering** uses a `JWindow` positioned at
  large negative screen coordinates to get a real native peer without
  visibly appearing. This is reliable on typical Windows/Linux desktop
  window managers but could behave differently under an unusual
  multi-monitor or remote-desktop setup — worth a quick visual check
  the first time you run it in your actual environment.
- **Session/token edge case**: if the app stores its session purely in
  `localStorage`/`sessionStorage` (never sent as a cookie or header),
  replaying via Burp's HTTP client won't carry it, since that data
  never touches the network.
